
export enum CampaignTone {
  PROFESSIONAL = 'Professionnel',
  CASUAL = 'Décontracté',
  INSPIRATIONAL = 'Inspirant',
  AUTHORITATIVE = 'Autoritaire'
}

export enum AnalysisEngine {
  INTERNAL = 'Onari Engine (Gemini)',
  EXTERNAL = 'Automation (n8n)'
}

export interface SocialMediaPost {
  id: string;
  plateforme: 'LinkedIn' | 'Instagram';
  type?: string; 
  hook?: string;
  body: string;
  cta?: string;
  hashtags: string[];
  conseil_visuel: string;
  scheduledDate?: string;
  status: 'draft' | 'scheduled' | 'published';
  mediaUrl?: string;
  mediaType?: 'image' | 'video';
  // Analytics Data
  metrics?: {
    views: number;
    likes: number;
    comments: number;
    shares: number;
    ctr: number;
  };
}

export interface AudienceDemographic {
  label: string;
  percentage: number;
  category: 'Job' | 'Industry' | 'Location';
}

export interface Competitor {
  id: string;
  name: string;
  avatar: string;
  headline: string;
  followers: number;
  growthRate: number; // en %
  lastPostPerformance: 'High' | 'Medium' | 'Low';
  topTopics: string[];
}

export interface AnalyticsReport {
  globalScore: number;
  audienceMatchScore: number; // Est-ce qu'on touche la bonne cible ?
  demographics: AudienceDemographic[];
  topPerformingPosts: SocialMediaPost[];
  competitors: Competitor[];
  aiAnalysis: string; // L'interprétation textuelle de l'IA
}

export interface ContentIdea {
  id: string;
  title: string;
  angle: string;
  potential: 'High' | 'Medium' | 'Viral';
}

export interface MarketingStrategy {
  strategie_du_jour: string;
  optimizationScore: number;
  profileAnalysis: {
    strengths: string[];
    weaknesses: string[];
    opportunities: string[];
  };
  posts: SocialMediaPost[];
  ideas?: ContentIdea[];
  planning: string;
}

export interface LinkedInProfile {
  name: string;
  headline: string;
  avatar: string; // URL de l'image
  url: string;
  connections: number;
  connectedAt?: string;
}

export interface Campaign {
  id: string;
  linkedinUrl: string;
  goal: string;
  sector: string;
  tone: CampaignTone;
  targetAudience?: string;
  currentChallenge?: string;
  createdAt: string;
  status: 'pending' | 'completed';
  result?: MarketingStrategy;
}

export interface User {
  id: string;
  email: string;
  name: string;
  credits: number;
  role: 'user' | 'admin';
  linkedInConnected: boolean;
  linkedInProfile?: LinkedInProfile;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}
