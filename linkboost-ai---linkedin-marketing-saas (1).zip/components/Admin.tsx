
import React, { useState, useEffect } from 'react';
import { n8nService } from '../services/n8nService';
import { campaignService } from '../services/campaignService';
import { AnalysisEngine } from '../types';

const Admin: React.FC = () => {
  const [engine, setEngine] = useState<AnalysisEngine>(AnalysisEngine.INTERNAL);
  const [webhookUrl, setWebhookUrl] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [saveStatus, setSaveStatus] = useState('');

  useEffect(() => {
    setEngine(campaignService.getEngine());
    setWebhookUrl(n8nService.getWebhookUrl());
    setApiKey(n8nService.getApiKey());
  }, []);

  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();
    campaignService.setEngine(engine);
    n8nService.setWebhookUrl(webhookUrl);
    n8nService.setApiKey(apiKey);
    setSaveStatus('Toutes les configurations sauvegardées !');
    setTimeout(() => setSaveStatus(''), 3000);
  };

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Configuration Système</h1>
        <p className="text-slate-500">Gérez l'intelligence et les automatisations de LinkBoost.</p>
      </header>

      <div className="space-y-8">
        {/* CHOIX DU MOTEUR */}
        <section className="bg-white rounded-3xl border p-8 shadow-sm">
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
            <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            Moteur d'Intelligence
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {Object.values(AnalysisEngine).map((e) => (
              <button
                key={e}
                onClick={() => setEngine(e)}
                className={`p-6 rounded-2xl border-2 text-left transition-all ${
                  engine === e 
                  ? 'border-blue-600 bg-blue-50' 
                  : 'border-slate-100 hover:border-slate-200 bg-white'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className={`font-bold ${engine === e ? 'text-blue-700' : 'text-slate-900'}`}>{e}</span>
                  {engine === e && <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>}
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">
                  {e === AnalysisEngine.INTERNAL 
                    ? "Utilise Gemini Pro pour une analyse instantanée sans dépendance externe. Plus rapide et fiable."
                    : "Connecte-toi à tes propres workflows n8n pour des traitements personnalisés (Scraping, etc.)"
                  }
                </p>
              </button>
            ))}
          </div>
        </section>

        {/* CONFIGURATION N8N (Conditionnelle) */}
        {engine === AnalysisEngine.EXTERNAL && (
          <section className="bg-white rounded-3xl border p-8 shadow-sm animate-in fade-in slide-in-from-top-4">
            <h2 className="text-xl font-bold mb-6">Paramètres n8n</h2>
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 uppercase">Webhook URL</label>
                <input 
                  type="url"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-100 font-mono text-sm"
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 uppercase">Secret API Key</label>
                <input 
                  type="password"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none focus:ring-4 focus:ring-blue-100 font-mono text-sm"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                />
              </div>
            </div>
          </section>
        )}

        <div className="flex items-center justify-between bg-slate-900 p-6 rounded-2xl text-white">
          <div>
            <p className="text-sm opacity-70">Le changement de moteur s'applique instantanément à toutes les nouvelles campagnes.</p>
          </div>
          <button 
            onClick={handleSaveAll}
            className="bg-blue-600 hover:bg-blue-700 px-8 py-3 rounded-xl font-bold transition-all shadow-xl shadow-blue-500/20"
          >
            {saveStatus || "Sauvegarder les réglages"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Admin;
