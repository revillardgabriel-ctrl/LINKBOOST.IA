
import React, { useState, useEffect } from 'react';
import { LinkedInProfile } from '../types';

interface LinkedInConnectModalProps {
  onClose: () => void;
  onConnect: (profile: LinkedInProfile) => void;
}

const LinkedInConnectModal: React.FC<LinkedInConnectModalProps> = ({ onClose }) => {
  const [error, setError] = useState('');
  const [showConfig, setShowConfig] = useState(true);

  // --- CONFIGURATION OAUTH LINKEDIN ---
  // Remplacez par votre Vrai Client ID fourni par LinkedIn Developers
  // Pour la production, vous pouvez aussi le mettre dans .env (import.meta.env.VITE_LINKEDIN_CLIENT_ID)
  const LINKEDIN_CLIENT_ID = "VOTRE_CLIENT_ID_ICI"; 
  
  // URL de redirection OAuth
  // IMPORTANT : Utilise window.location.origin pour marcher aussi bien sur localhost que sur vercel.app
  // Exemple Local : http://localhost:5173/#/auth/callback
  // Exemple Prod : https://linkboost-app.vercel.app/#/auth/callback
  // Note: LinkedIn n'aime pas les # dans les redirect URIs standards, mais avec HashRouter c'est parfois tricky.
  // Pour Vercel + API, on préfère souvent une redirection vers le backend ou une route claire.
  // Ici, nous utilisons la route frontend que nous avons définie dans App.tsx
  const [redirectUri, setRedirectUri] = useState("");
  const [privacyUrl, setPrivacyUrl] = useState("");

  useEffect(() => {
     // Construction dynamique des URLs
     const origin = window.location.origin;
     // On pointe vers la route définie dans App.tsx
     setRedirectUri(`${origin}/#/auth/callback`);
     setPrivacyUrl(`${origin}/#/privacy`);
  }, []);

  const SCOPE = "r_liteprofile r_emailaddress w_member_social";

  const handleRealOAuthClick = () => {
    if (LINKEDIN_CLIENT_ID === "VOTRE_CLIENT_ID_ICI") {
        setError("Erreur : Ajoutez votre Client ID dans le code (components/LinkedInConnectModal.tsx).");
        return;
    }

    const state = Math.random().toString(36).substring(7);
    localStorage.setItem('linkedin_oauth_state', state);

    // Note : LinkedIn n'accepte pas toujours les fragments (#) dans redirect_uri.
    // Si cela échoue, il faudra configurer le routeur en mode 'history' (BrowserRouter) au lieu de HashRouter,
    // ce qui nécessite une configuration spéciale sur Vercel (rewrites).
    // Pour cette démo, on tente avec le hash. Si LinkedIn bloque, enlevez le /#/ ici et dans LinkedIn Dev.
    const authUrl = `https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=${LINKEDIN_CLIENT_ID}&redirect_uri=${encodeURIComponent(redirectUri)}&state=${state}&scope=${encodeURIComponent(SCOPE)}`;

    window.location.href = authUrl;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden relative max-h-[90vh] overflow-y-auto">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 z-10">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>

        <div className="p-8 pb-4 text-center">
            <div className="w-16 h-16 bg-[#0077b5] rounded-xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-blue-500/30">
                <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
            </div>

            <h2 className="text-2xl font-black text-slate-900 mb-2">Connecter LinkedIn</h2>
            <p className="text-slate-500 text-sm mb-6">
                Redirection sécurisée vers LinkedIn pour l'authentification OAuth 2.0.
            </p>
            
            {error && (
                <div className="mb-6 p-3 bg-red-50 text-red-600 text-xs font-bold rounded-lg border border-red-100 text-left">
                    ⚠️ {error}
                </div>
            )}

            <button 
                onClick={handleRealOAuthClick}
                className="w-full py-4 bg-[#0077b5] hover:bg-[#006097] text-white font-bold rounded-xl transition-all shadow-xl shadow-blue-500/20 flex items-center justify-center gap-3 group"
            >
                <span className="bg-white/20 p-1 rounded">
                    <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                </span>
                S'identifier avec LinkedIn
            </button>
        </div>

        {/* SECTION AIDE CONFIGURATION */}
        <div className="bg-slate-50 border-t border-slate-100 p-6">
             <button 
                onClick={() => setShowConfig(!showConfig)}
                className="w-full flex justify-between items-center text-xs font-bold uppercase text-slate-400 hover:text-slate-600 mb-4"
             >
                <span>🔧 Configuration Serveur (Production)</span>
                <span>{showConfig ? '−' : '+'}</span>
             </button>

             {showConfig && (
                 <div className="space-y-4 animate-in slide-in-from-top-2">
                     <div className="bg-amber-50 border border-amber-100 p-3 rounded-lg text-[10px] text-amber-800 leading-relaxed mb-2">
                        <strong>Important :</strong> Une fois le site déployé (Vercel), copiez ces 2 URLs dans votre portail LinkedIn Developer > Auth > OAuth 2.0 settings.
                     </div>
                     
                     {/* URL REDIRECTION */}
                     <div className="group">
                        <label className="text-[10px] font-bold text-slate-500 uppercase flex items-center gap-2">
                           Authorized Redirect URL
                        </label>
                        <div className="flex gap-2 mt-1">
                            <code className="flex-1 bg-white border border-slate-200 px-3 py-2 rounded-lg text-xs font-mono text-slate-700 truncate select-all">
                                {redirectUri}
                            </code>
                            <button 
                                onClick={() => copyToClipboard(redirectUri)}
                                className="bg-white border border-slate-200 px-3 rounded-lg text-slate-500 hover:text-blue-600 hover:border-blue-200 text-xs font-bold transition-colors"
                            >
                                Copier
                            </button>
                        </div>
                     </div>

                     {/* URL PRIVACY */}
                     <div className="group">
                        <label className="text-[10px] font-bold text-slate-500 uppercase flex items-center gap-2">
                           Lien Politique de Confidentialité
                        </label>
                        <div className="flex gap-2 mt-1">
                            <code className="flex-1 bg-white border border-slate-200 px-3 py-2 rounded-lg text-xs font-mono text-slate-700 truncate select-all">
                                {privacyUrl}
                            </code>
                            <button 
                                onClick={() => copyToClipboard(privacyUrl)}
                                className="bg-white border border-slate-200 px-3 rounded-lg text-slate-500 hover:text-blue-600 hover:border-blue-200 text-xs font-bold transition-colors"
                            >
                                Copier
                            </button>
                        </div>
                     </div>
                 </div>
             )}
        </div>
      </div>
    </div>
  );
};

export default LinkedInConnectModal;
