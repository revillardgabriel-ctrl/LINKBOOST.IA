
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, Campaign, LinkedInProfile } from '../types';

interface DashboardProps {
  user: User;
  campaigns: Campaign[];
  onConnect: (profile: LinkedInProfile) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, campaigns, onConnect }) => {
  const navigate = useNavigate();
  const latestCampaign = campaigns[0];

  const activities = [
    { id: 1, type: 'content', title: '5 posts générés', desc: 'Campagne BTP', time: '2 min', icon: '📝' },
    { id: 2, type: 'data', title: 'Analyse terminée', desc: 'Profil Expert', time: '15 min', icon: '📊' },
    { id: 3, type: 'lead', title: '3 opportunités', desc: 'Détection IA', time: '1h', icon: '🎯' },
  ];

  const upcomingPosts = latestCampaign?.result?.posts.slice(0, 3) || [];

  return (
    <div className="p-8 max-w-[1600px] mx-auto space-y-6">
      
      {/* HEADER */}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center mb-2">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Vue d'ensemble</h1>
          <p className="text-slate-500 text-sm">Bienvenue, {user.name}. Voici ce qui se passe aujourd'hui.</p>
        </div>
        <div className="flex gap-3">
            <button className="px-4 py-2 bg-white border border-slate-200 text-slate-700 text-sm font-medium rounded-lg hover:bg-slate-50 transition-colors">
                Exporter le rapport
            </button>
            <Link 
            to="/campaign/new" 
            className="px-4 py-2 bg-slate-900 text-white text-sm font-medium rounded-lg hover:bg-slate-800 transition-all flex items-center gap-2 shadow-sm"
            >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"/></svg>
            Nouvelle Campagne
            </Link>
        </div>
      </header>
      
      {/* ALERT CONNECT LINKEDIN */}
      {!user.linkedInConnected && (
        <div className="bg-[#0077b5] rounded-xl p-6 text-white shadow-lg shadow-blue-500/20 flex items-center justify-between animate-in slide-in-from-top-4">
            <div className="flex items-center gap-4">
                <div className="p-3 bg-white/10 rounded-lg backdrop-blur-sm">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                </div>
                <div>
                    <h3 className="font-bold text-lg">Connectez votre compte LinkedIn</h3>
                    <p className="text-blue-100 text-sm">Activez la publication automatique et l'analyse en temps réel de votre profil.</p>
                </div>
            </div>
            <button 
                onClick={() => onConnect({} as any)} // Le Dashboard ne gère pas la modale, il délègue au parent
                className="px-6 py-3 bg-white text-[#0077b5] font-bold rounded-lg hover:bg-blue-50 transition-colors shadow-sm"
            >
                Connecter maintenant
            </button>
        </div>
      )}

      {/* KPI GRID - Style "Metric Card" */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
            </div>
            <span className="flex items-center text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-md">
              +12.5%
            </span>
          </div>
          <p className="text-slate-500 text-xs font-medium uppercase tracking-wider">Audience</p>
          <h3 className="text-2xl font-bold text-slate-900 mt-1">12,450</h3>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-purple-50 text-purple-600 rounded-lg">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            </div>
            <span className="flex items-center text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-md">
              +4.8%
            </span>
          </div>
          <p className="text-slate-500 text-xs font-medium uppercase tracking-wider">Engagement</p>
          <h3 className="text-2xl font-bold text-slate-900 mt-1">4.8%</h3>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            </div>
          </div>
          <p className="text-slate-500 text-xs font-medium uppercase tracking-wider">Posts Prêts</p>
          <h3 className="text-2xl font-bold text-slate-900 mt-1">{latestCampaign?.result?.posts.filter(p => p.status === 'draft').length || 0}</h3>
        </div>

        <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-5 rounded-xl border border-slate-800 shadow-sm text-white flex flex-col justify-between">
           <div>
              <p className="text-slate-400 text-xs font-medium uppercase mb-1">Quota Restant</p>
              <h3 className="text-2xl font-bold">{user.credits} <span className="text-sm font-normal text-slate-400">/ 50</span></h3>
           </div>
           <button className="text-xs bg-white/10 hover:bg-white/20 text-white py-2 rounded-lg transition-colors font-medium">
              Gérer mon plan
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* GRAPH & ANALYTICS */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
             <div className="flex justify-between items-center mb-6">
                <h3 className="text-base font-bold text-slate-900">Performance de contenu</h3>
                <div className="flex gap-2">
                    <button className="text-xs font-medium text-slate-600 bg-slate-100 px-3 py-1.5 rounded-md hover:bg-slate-200 transition-colors">7J</button>
                    <button className="text-xs font-medium text-white bg-slate-900 px-3 py-1.5 rounded-md">30J</button>
                </div>
             </div>
             <div className="h-64 w-full relative bg-slate-50/50 rounded-lg border border-slate-100 flex items-end justify-between px-4 pb-0 overflow-hidden">
                {/* Simulated Chart Bars */}
                {[30, 45, 35, 60, 50, 75, 65, 80, 70, 90, 85, 95].map((h, i) => (
                    <div key={i} className="w-full mx-1 bg-blue-100 rounded-t-sm hover:bg-blue-200 transition-colors relative group" style={{ height: `${h}%` }}>
                        <div className="absolute bottom-0 w-full bg-blue-500 h-[20%] rounded-t-sm opacity-80 group-hover:opacity-100"></div>
                    </div>
                ))}
             </div>
          </div>

          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
             <div className="flex justify-between items-center mb-4">
                <h3 className="text-base font-bold text-slate-900">À publier cette semaine</h3>
                <Link to="/planning" className="text-blue-600 text-xs font-medium hover:underline">Voir le calendrier</Link>
             </div>
             
             <div className="space-y-3">
               {upcomingPosts.length > 0 ? upcomingPosts.map((post, i) => (
                 <div key={i} className="flex items-center gap-4 p-4 rounded-lg border border-slate-100 hover:border-blue-200 hover:bg-blue-50/30 transition-all group cursor-pointer" onClick={() => navigate('/studio')}>
                    <div className="flex flex-col items-center justify-center w-12 h-12 bg-slate-50 rounded-lg border border-slate-200 text-slate-500 group-hover:text-blue-600 group-hover:border-blue-200">
                        <span className="text-[10px] font-bold uppercase">J+{i+1}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded text-slate-500 bg-slate-100 border border-slate-200">{post.type || 'Post'}</span>
                            <span className="text-xs text-slate-400 truncate">Suggéré pour 10:00</span>
                        </div>
                        <p className="text-sm font-medium text-slate-900 truncate group-hover:text-blue-700">{post.hook}</p>
                    </div>
                    <button className="text-slate-400 hover:text-blue-600">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                    </button>
                 </div>
               )) : (
                 <div className="text-center py-6 text-slate-500 text-sm">Aucun post planifié.</div>
               )}
             </div>
          </div>
        </div>

        {/* SIDEBAR WIDGETS */}
        <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                <h3 className="text-base font-bold text-slate-900 mb-4">Flux d'activité</h3>
                <div className="relative pl-4 space-y-6">
                    <div className="absolute left-0 top-2 bottom-2 w-px bg-slate-200"></div>
                    {activities.map((act) => (
                        <div key={act.id} className="relative text-sm">
                            <div className="absolute -left-[21px] top-1.5 w-2.5 h-2.5 rounded-full bg-white border-2 border-slate-300"></div>
                            <div className="flex justify-between items-start">
                                <div>
                                    <p className="font-medium text-slate-900">{act.title}</p>
                                    <p className="text-slate-500 text-xs">{act.desc}</p>
                                </div>
                                <span className="text-xs text-slate-400">{act.time}</span>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="bg-blue-600 rounded-xl p-6 text-white shadow-lg shadow-blue-600/20">
                <h3 className="font-bold text-lg mb-2">Conseil du jour</h3>
                <p className="text-blue-100 text-sm mb-4 leading-relaxed">
                    Vos posts "Autorité" ont généré 40% plus d'engagement le mardi matin.
                </p>
                <button className="w-full py-2 bg-white text-blue-600 text-sm font-semibold rounded-lg hover:bg-blue-50 transition-colors">
                    Planifier un post
                </button>
            </div>
        </div>

      </div>
    </div>
  );
};

export default Dashboard;
