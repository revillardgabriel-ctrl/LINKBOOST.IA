
import React, { useState } from 'react';
import { User, LinkedInProfile } from '../types';

interface SettingsProps {
  user: User;
  onDisconnect: () => void;
}

const Settings: React.FC<SettingsProps> = ({ user, onDisconnect }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'billing' | 'privacy'>('privacy');

  return (
    <div className="p-8 max-w-5xl mx-auto min-h-screen pb-20">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Paramètres du compte</h1>
        <p className="text-slate-500">Gérez vos préférences, votre abonnement et vos informations légales.</p>
      </header>

      {/* TABS NAVIGATION */}
      <div className="flex border-b border-slate-200 mb-8 overflow-x-auto">
        <button
          onClick={() => setActiveTab('profile')}
          className={`px-6 py-4 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'profile' 
              ? 'border-blue-600 text-blue-600' 
              : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
          }`}
        >
          👤 Profil & Connexions
        </button>
        <button
          onClick={() => setActiveTab('billing')}
          className={`px-6 py-4 text-sm font-bold border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'billing' 
              ? 'border-blue-600 text-blue-600' 
              : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
          }`}
        >
          💳 Abonnement & Crédits
        </button>
        <button
          onClick={() => setActiveTab('privacy')}
          className={`px-6 py-4 text-sm font-bold border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'privacy' 
              ? 'border-blue-600 text-blue-600' 
              : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
          }`}
        >
          🛡️ Politique de Confidentialité
        </button>
      </div>

      {/* CONTENU DES ONGLETS */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
        
        {/* ONGLET PROFIL */}
        {activeTab === 'profile' && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2">
            <div>
              <h2 className="text-lg font-bold text-slate-900 mb-4">Informations Personnelles</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-400 mb-2">Nom complet</label>
                  <input type="text" value={user.name} disabled className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-slate-700 font-medium" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-400 mb-2">Email</label>
                  <input type="email" value={user.email} disabled className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-slate-700 font-medium" />
                </div>
              </div>
            </div>

            <div className="pt-8 border-t border-slate-100">
              <h2 className="text-lg font-bold text-slate-900 mb-4">Connexion LinkedIn</h2>
              {user.linkedInConnected ? (
                <div className="bg-blue-50 border border-blue-100 rounded-xl p-6 flex justify-between items-center">
                   <div className="flex items-center gap-4">
                      {user.linkedInProfile?.avatar ? (
                        <img src={user.linkedInProfile.avatar} className="w-12 h-12 rounded-full border-2 border-white shadow-sm" alt="Avatar" />
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-xl">{user.name.charAt(0)}</div>
                      )}
                      <div>
                        <p className="font-bold text-slate-900">{user.linkedInProfile?.name}</p>
                        <p className="text-sm text-blue-600">{user.linkedInProfile?.headline || "Profil Connecté"}</p>
                      </div>
                   </div>
                   <button onClick={onDisconnect} className="text-sm font-bold text-red-500 hover:text-red-700 bg-white border border-red-100 px-4 py-2 rounded-lg hover:bg-red-50 transition-colors">
                      Déconnecter
                   </button>
                </div>
              ) : (
                <div className="bg-slate-50 border border-slate-100 rounded-xl p-6 text-center">
                  <p className="text-slate-500 mb-4">Aucun compte LinkedIn associé.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ONGLET BILLING */}
        {activeTab === 'billing' && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2">
             <div className="flex items-center justify-between p-6 bg-slate-900 text-white rounded-xl shadow-lg">
                <div>
                  <p className="text-slate-400 text-xs font-bold uppercase mb-1">Plan Actuel</p>
                  <h2 className="text-2xl font-black">LinkBoost Pro</h2>
                </div>
                <div className="text-right">
                  <p className="text-slate-400 text-xs font-bold uppercase mb-1">Crédits Restants</p>
                  <h2 className="text-3xl font-black text-blue-400">{user.credits}</h2>
                </div>
             </div>
             <div>
                <h3 className="font-bold text-slate-900 mb-4">Historique de facturation</h3>
                <table className="w-full text-sm text-left">
                  <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4 font-bold">Date</th>
                      <th className="py-3 px-4 font-bold">Montant</th>
                      <th className="py-3 px-4 font-bold">Statut</th>
                      <th className="py-3 px-4 font-bold text-right">Facture</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-slate-50">
                      <td className="py-4 px-4 text-slate-900">01/10/2023</td>
                      <td className="py-4 px-4 text-slate-600">59.00 €</td>
                      <td className="py-4 px-4"><span className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-bold">Payé</span></td>
                      <td className="py-4 px-4 text-right"><button className="text-blue-600 hover:underline">PDF</button></td>
                    </tr>
                  </tbody>
                </table>
             </div>
          </div>
        )}

        {/* ONGLET CONFIDENTIALITÉ (Contenu de PrivacyPolicy.tsx intégré) */}
        {activeTab === 'privacy' && (
          <div className="animate-in fade-in slide-in-from-bottom-2">
            <div className="prose prose-slate max-w-none">
              <h2 className="text-2xl font-black text-slate-900 mb-6">Politique de Confidentialité LinkBoost AI</h2>
              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-8 text-sm text-blue-800">
                <strong>Important :</strong> Cette page décrit comment nous traitons vos données LinkedIn conformément aux exigences RGPD et aux conditions d'utilisation de l'API LinkedIn.
              </div>

              <h3 className="text-lg font-bold text-slate-800 mt-6 mb-3">1. Collecte des données</h3>
              <p className="text-slate-600 mb-4">
                Lorsque vous connectez votre compte LinkedIn, nous collectons uniquement les données strictement nécessaires au fonctionnement de l'IA :
              </p>
              <ul className="list-disc pl-5 mb-6 text-slate-600 space-y-2">
                <li>Votre identifiant unique LinkedIn (pour lier votre compte).</li>
                <li>Votre nom et photo de profil (pour personnaliser l'interface).</li>
                <li>Votre adresse email (pour l'authentification et la facturation).</li>
                <li>Les statistiques de vos posts (pour l'analyse de performance).</li>
              </ul>

              <h3 className="text-lg font-bold text-slate-800 mt-6 mb-3">2. Utilisation des données</h3>
              <p className="text-slate-600 mb-4">
                Vos données ne sont utilisées que dans le cadre de l'application LinkBoost pour :
              </p>
              <ul className="list-disc pl-5 mb-6 text-slate-600 space-y-2">
                <li>Générer des suggestions de contenu via nos modèles IA.</li>
                <li>Créer des rapports statistiques sur votre audience.</li>
                <li>Planifier la publication de vos posts (uniquement avec votre validation explicite).</li>
              </ul>

              <h3 className="text-lg font-bold text-slate-800 mt-6 mb-3">3. Stockage et Sécurité</h3>
              <p className="text-slate-600 mb-4">
                Les tokens d'accès (OAuth) sont cryptés. Nous ne stockons jamais votre mot de passe LinkedIn. 
                Aucune donnée n'est revendue à des tiers publicitaires.
              </p>

              <h3 className="text-lg font-bold text-slate-800 mt-6 mb-3">4. Suppression des données</h3>
              <p className="text-slate-600 mb-6">
                Vous pouvez supprimer votre compte LinkBoost à tout moment. Cela entraînera la suppression immédiate et définitive de toutes vos données de nos serveurs.
                Vous pouvez également révoquer l'accès via les <a href="https://www.linkedin.com/psettings/permitted-services" target="_blank" className="text-blue-600 underline">paramètres LinkedIn</a>.
              </p>

              <div className="mt-8 pt-8 border-t border-slate-200 flex justify-between items-center">
                 <p className="text-xs text-slate-400">Dernière mise à jour : {new Date().toLocaleDateString()}</p>
                 <button className="text-red-500 font-bold text-sm hover:underline">Demander la suppression de mes données</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Settings;
