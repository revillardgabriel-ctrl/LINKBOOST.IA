
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User } from '../types';

interface NavbarProps {
  user: User | null;
  login: (u: User) => void;
  logout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, login, logout }) => {
  const navigate = useNavigate();

  const handleMockLogin = () => {
    // Fix: Added missing linkedInConnected property to satisfy User type
    login({
      id: '1',
      email: 'jean.dupont@example.com',
      name: 'Jean Dupont',
      credits: 10,
      role: 'admin',
      linkedInConnected: false
    });
    navigate('/dashboard');
  };

  return (
    <nav className="h-16 border-b bg-white flex items-center justify-between px-6 sticky top-0 z-10">
      <div className="flex items-center gap-2">
        {!user && (
          <Link to="/" className="text-xl font-bold text-blue-600 tracking-tight flex items-center gap-2">
            <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z"/></svg>
            LinkBoost AI
          </Link>
        )}
      </div>

      <div className="flex items-center gap-4">
        {user ? (
          <div className="flex items-center gap-4">
            <div className="hidden md:flex flex-col items-end">
              <span className="text-sm font-medium text-slate-900">{user.name}</span>
              <span className="text-xs text-slate-500">{user.credits} crédits restants</span>
            </div>
            <button 
              onClick={logout}
              className="text-sm text-slate-500 hover:text-red-600 font-medium"
            >
              Déconnexion
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-4">
            <button 
              onClick={handleMockLogin}
              className="text-sm font-semibold text-slate-600 hover:text-slate-900"
            >
              Connexion
            </button>
            <button 
              onClick={handleMockLogin}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-blue-700 transition-colors shadow-sm"
            >
              Commencer gratuitement
            </button>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
