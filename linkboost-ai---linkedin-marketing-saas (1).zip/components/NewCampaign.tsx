
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Campaign, CampaignTone, User } from '../types';
import { campaignService } from '../services/campaignService';

interface NewCampaignProps {
  onAdd: (c: Campaign) => void;
  user: User;
}

const NewCampaign: React.FC<NewCampaignProps> = ({ onAdd, user }) => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    linkedinUrl: user.linkedInConnected ? (user.linkedInProfile?.url || '') : '',
    goal: 'Générer des Leads',
    sector: '',
    tone: CampaignTone.PROFESSIONAL,
    targetAudience: '',
    currentChallenge: '',
    duration: '1 semaine', // Nouveau paramètre stratégique
    frequency: '3 posts/semaine', // Nouveau paramètre stratégique
  });

  const totalSteps = 4;

  const analysisSteps = [
    "Analyse du profil & ton de voix...",
    "Définition des piliers éditoriaux...",
    "Structuration de la séquence (AIDA)...",
    "Rédaction des hooks viraux...",
    "Génération du planning...",
    "Finalisation de la stratégie..."
  ];

  const handleFinalSubmit = async () => {
    setLoading(true);
    setError(null);

    // Simulation d'étapes de chargement pour l'effet "Travail en cours"
    const stepInterval = setInterval(() => {
      setLoadingStep(prev => (prev < analysisSteps.length - 1 ? prev + 1 : prev));
    }, 1500);

    const newId = Math.random().toString(36).substring(7);
    
    // Création de l'objet campagne initial
    // On concatène les infos de durée dans le challenge pour que l'IA les prenne en compte via le service actuel
    const campaignContext = `${formData.currentChallenge} (Format: ${formData.duration}, Rythme: ${formData.frequency})`;

    const campaign: Campaign = {
      id: newId,
      linkedinUrl: formData.linkedinUrl,
      goal: formData.goal,
      sector: formData.sector,
      tone: formData.tone,
      targetAudience: formData.targetAudience,
      currentChallenge: campaignContext, 
      createdAt: new Date().toISOString(),
      status: 'pending'
    };

    onAdd(campaign);

    try {
      // On passe l'objet modifié au service
      const strategy = await campaignService.processCampaign({
          ...formData,
          currentChallenge: campaignContext
      });
      
      const completedCampaign: Campaign = { ...campaign, status: 'completed', result: strategy };
      onAdd(completedCampaign);
      clearInterval(stepInterval);
      navigate(`/campaign/results/${newId}`);
    } catch (err: any) {
      clearInterval(stepInterval);
      setError(err.message || "L'Architecte Onari a rencontré un problème.");
      setLoading(false);
    }
  };

  const nextStep = () => {
    if (step < totalSteps) setStep(step + 1);
    else handleFinalSubmit();
  };

  const prevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  // --- COMPOSANT DE CHARGEMENT ---
  if (loading) {
    return (
      <div className="fixed inset-0 bg-slate-900 z-50 flex flex-col items-center justify-center p-8 text-center text-white">
        <div className="relative w-32 h-32 mb-8">
          <div className="absolute inset-0 border-4 border-slate-700 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-blue-500 rounded-full border-t-transparent animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center font-black text-2xl animate-pulse">
            AI
          </div>
        </div>
        <h2 className="text-3xl font-bold mb-2 tracking-tight">{analysisSteps[loadingStep]}</h2>
        <p className="text-slate-400 max-w-md font-medium mb-8">Création de votre campagne "{formData.goal}" en cours...</p>
        
        {/* Terminal Effect */}
        <div className="w-full max-w-lg bg-slate-950 rounded-lg border border-slate-800 p-4 font-mono text-xs text-left opacity-80 shadow-2xl">
            <p className="text-green-400">> Initializing Campaign Protocol v2.4</p>
            <p className="text-blue-400">> Context: {formData.sector}</p>
            <p className="text-blue-400">> Target: {formData.targetAudience}</p>
            {loadingStep > 1 && <p className="text-slate-300">> Generating content matrix...</p>}
            {loadingStep > 2 && <p className="text-slate-300">> Optimizing hooks for viral potential...</p>}
            {loadingStep > 3 && <p className="text-slate-300">> Scheduling posts sequence ({formData.duration})...</p>}
            <span className="inline-block w-2 h-4 bg-green-500 animate-pulse mt-1"></span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row font-sans">
      
      {/* GAUCHE: FORMULAIRE INTERACTIF (WIZARD) */}
      <div className="w-full md:w-1/2 p-8 md:p-16 flex flex-col justify-center overflow-y-auto relative bg-white">
        <div className="max-w-xl mx-auto w-full z-10">
            <button onClick={() => navigate('/dashboard')} className="text-slate-400 hover:text-slate-800 mb-8 flex items-center gap-2 text-xs font-bold uppercase tracking-widest transition-colors">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                Annuler
            </button>
            
            <div className="mb-6 flex items-center gap-3">
                <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-blue-500/30">Étape {step}/{totalSteps}</span>
                <div className="h-1 flex-1 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-600 transition-all duration-500 ease-out" style={{ width: `${(step/totalSteps)*100}%` }}></div>
                </div>
            </div>

            {step === 1 && (
                <div className="animate-in slide-in-from-left-8 fade-in duration-500">
                    <h1 className="text-5xl font-black text-slate-900 mb-4 leading-tight tracking-tight">Le Briefing.</h1>
                    <p className="text-lg text-slate-500 mb-10 leading-relaxed">Commençons par les fondations. Qui êtes-vous et quelle est votre expertise ?</p>
                    
                    <div className="space-y-8">
                        <div className="group">
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 group-focus-within:text-blue-600 transition-colors">Votre Profil LinkedIn (URL)</label>
                            <input 
                                autoFocus
                                type="url" 
                                value={formData.linkedinUrl}
                                onChange={e => setFormData({ ...formData, linkedinUrl: e.target.value })}
                                className="w-full bg-slate-50 border-0 border-b-2 border-slate-200 px-0 py-4 text-xl font-bold text-slate-900 focus:border-blue-600 focus:ring-0 outline-none transition-all placeholder:text-slate-300"
                                placeholder="https://linkedin.com/in/..."
                            />
                        </div>
                        <div className="group">
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 group-focus-within:text-blue-600 transition-colors">Secteur d'Activité</label>
                            <input 
                                type="text" 
                                value={formData.sector}
                                onChange={e => setFormData({ ...formData, sector: e.target.value })}
                                className="w-full bg-slate-50 border-0 border-b-2 border-slate-200 px-0 py-4 text-xl font-bold text-slate-900 focus:border-blue-600 focus:ring-0 outline-none transition-all placeholder:text-slate-300"
                                placeholder="Ex: SaaS B2B, Architecture, Coaching..."
                            />
                        </div>
                    </div>
                </div>
            )}

            {step === 2 && (
                <div className="animate-in slide-in-from-left-8 fade-in duration-500">
                    <h1 className="text-5xl font-black text-slate-900 mb-4 leading-tight tracking-tight">Cible & Mission.</h1>
                    <p className="text-lg text-slate-500 mb-10 leading-relaxed">Définissons qui nous devons convaincre et quel est l'objectif final.</p>
                    
                    <div className="space-y-8">
                        <div className="group">
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 group-focus-within:text-blue-600 transition-colors">Audience Cible (Persona)</label>
                            <textarea 
                                autoFocus
                                rows={2}
                                value={formData.targetAudience}
                                onChange={e => setFormData({ ...formData, targetAudience: e.target.value })}
                                className="w-full bg-slate-50 border-0 border-b-2 border-slate-200 px-0 py-4 text-xl font-bold text-slate-900 focus:border-blue-600 focus:ring-0 outline-none transition-all resize-none placeholder:text-slate-300"
                                placeholder="Ex: DRH de start-ups en croissance, Architectes..."
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Objectif Principal</label>
                            <div className="grid grid-cols-2 gap-4">
                                {['Notoriété', 'Génération de Leads', 'Personal Branding', 'Recrutement'].map(g => (
                                    <button
                                        key={g}
                                        onClick={() => setFormData({ ...formData, goal: g })}
                                        className={`px-6 py-4 rounded-2xl border-2 text-sm font-bold text-left transition-all duration-200 ${
                                            formData.goal === g 
                                            ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-lg shadow-blue-100 transform scale-[1.02]' 
                                            : 'border-slate-100 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50'
                                        }`}
                                    >
                                        {g}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {step === 3 && (
                <div className="animate-in slide-in-from-left-8 fade-in duration-500">
                    <h1 className="text-5xl font-black text-slate-900 mb-4 leading-tight tracking-tight">La Stratégie.</h1>
                    <p className="text-lg text-slate-500 mb-10 leading-relaxed">Quelle intensité pour cette campagne ? Sprint ou Marathon ?</p>
                    
                    <div className="space-y-8">
                        <div>
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Format de Campagne</label>
                            <div className="grid grid-cols-1 gap-4">
                                <button
                                    onClick={() => setFormData({ ...formData, duration: '1 semaine', frequency: '5 posts/semaine' })}
                                    className={`p-5 rounded-2xl border-2 text-left transition-all duration-200 flex items-start gap-5 group ${formData.duration === '1 semaine' ? 'border-blue-600 bg-blue-50 shadow-xl shadow-blue-100 transform scale-[1.02]' : 'border-slate-100 bg-white hover:border-slate-300'}`}
                                >
                                    <div className={`p-3 rounded-xl border shadow-sm text-2xl transition-colors ${formData.duration === '1 semaine' ? 'bg-white border-blue-100' : 'bg-slate-50 border-slate-100'}`}>⚡️</div>
                                    <div>
                                        <h3 className={`font-black text-lg ${formData.duration === '1 semaine' ? 'text-blue-700' : 'text-slate-900'}`}>Le Sprint (1 Semaine)</h3>
                                        <p className="text-sm text-slate-500 mt-1 font-medium leading-snug">5 posts intenses. Idéal pour un lancement, une annonce ou créer un pic de visibilité immédiat.</p>
                                    </div>
                                </button>
                                <button
                                    onClick={() => setFormData({ ...formData, duration: '2 semaines', frequency: '3 posts/semaine' })}
                                    className={`p-5 rounded-2xl border-2 text-left transition-all duration-200 flex items-start gap-5 group ${formData.duration === '2 semaines' ? 'border-blue-600 bg-blue-50 shadow-xl shadow-blue-100 transform scale-[1.02]' : 'border-slate-100 bg-white hover:border-slate-300'}`}
                                >
                                    <div className={`p-3 rounded-xl border shadow-sm text-2xl transition-colors ${formData.duration === '2 semaines' ? 'bg-white border-blue-100' : 'bg-slate-50 border-slate-100'}`}>🏃</div>
                                    <div>
                                        <h3 className={`font-black text-lg ${formData.duration === '2 semaines' ? 'text-blue-700' : 'text-slate-900'}`}>Le Standard (2 Semaines)</h3>
                                        <p className="text-sm text-slate-500 mt-1 font-medium leading-snug">6 posts équilibrés. Parfait pour construire l'autorité et engager votre communauté.</p>
                                    </div>
                                </button>
                                <button
                                    onClick={() => setFormData({ ...formData, duration: '1 mois', frequency: '2 posts/semaine' })}
                                    className={`p-5 rounded-2xl border-2 text-left transition-all duration-200 flex items-start gap-5 group ${formData.duration === '1 mois' ? 'border-blue-600 bg-blue-50 shadow-xl shadow-blue-100 transform scale-[1.02]' : 'border-slate-100 bg-white hover:border-slate-300'}`}
                                >
                                    <div className={`p-3 rounded-xl border shadow-sm text-2xl transition-colors ${formData.duration === '1 mois' ? 'bg-white border-blue-100' : 'bg-slate-50 border-slate-100'}`}>🏔️</div>
                                    <div>
                                        <h3 className={`font-black text-lg ${formData.duration === '1 mois' ? 'text-blue-700' : 'text-slate-900'}`}>Le Marathon (1 Mois)</h3>
                                        <p className="text-sm text-slate-500 mt-1 font-medium leading-snug">8 posts de fond. Idéal pour le SEO, l'éducation de marché et la présence long terme.</p>
                                    </div>
                                </button>
                            </div>
                        </div>

                        <div>
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Ton de voix</label>
                            <div className="flex gap-3 overflow-x-auto pb-2 custom-scrollbar">
                                {Object.values(CampaignTone).map(t => (
                                    <button
                                        key={t}
                                        onClick={() => setFormData({ ...formData, tone: t })}
                                        className={`px-6 py-3 rounded-full border-2 text-sm font-bold whitespace-nowrap transition-all ${
                                            formData.tone === t 
                                            ? 'bg-slate-900 text-white border-slate-900 shadow-lg' 
                                            : 'bg-white text-slate-600 border-slate-200 hover:border-slate-400'
                                        }`}
                                    >
                                        {t}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {step === 4 && (
                <div className="animate-in slide-in-from-left-8 fade-in duration-500">
                    <h1 className="text-5xl font-black text-slate-900 mb-4 leading-tight tracking-tight">Le Message.</h1>
                    <p className="text-lg text-slate-500 mb-10 leading-relaxed">Quel est le point de douleur majeur ou l'angle spécifique de cette campagne ?</p>
                    
                    <div className="space-y-6">
                        <div className="group">
                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 group-focus-within:text-blue-600 transition-colors">Angle / Challenge</label>
                            <textarea 
                                autoFocus
                                rows={4}
                                value={formData.currentChallenge}
                                onChange={e => setFormData({ ...formData, currentChallenge: e.target.value })}
                                className="w-full bg-slate-50 border-0 border-b-2 border-slate-200 px-0 py-4 text-2xl font-bold text-slate-900 focus:border-blue-600 focus:ring-0 outline-none transition-all resize-none placeholder:text-slate-300 leading-snug"
                                placeholder="Ex: Mes clients pensent que l'architecture coûte trop cher. Je veux prouver que c'est un investissement..."
                            />
                        </div>
                    </div>
                </div>
            )}

            <div className="mt-16 flex items-center justify-between">
                <button 
                    onClick={prevStep}
                    disabled={step === 1}
                    className={`px-6 py-3 rounded-xl font-bold transition-colors ${step === 1 ? 'text-slate-300 cursor-not-allowed' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'}`}
                >
                    Retour
                </button>
                <button 
                    onClick={nextStep}
                    className="px-10 py-5 bg-blue-600 text-white font-black rounded-2xl hover:bg-blue-700 hover:scale-105 transition-all shadow-2xl shadow-blue-500/40 flex items-center gap-3 text-lg group"
                >
                    {step === totalSteps ? 'Lancer la Campagne' : 'Continuer'}
                    <svg className="w-6 h-6 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                </button>
            </div>
            {error && <p className="mt-6 text-red-500 font-bold text-center bg-red-50 p-4 rounded-xl">{error}</p>}
        </div>
      </div>

      {/* DROITE: PREVIEW 'MANIFESTE' (Manifesto) */}
      <div className="hidden md:flex w-1/2 bg-slate-900 p-16 flex-col justify-center relative overflow-hidden">
        {/* Background Effects */}
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-600/20 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2 pointer-events-none mix-blend-screen animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-purple-600/10 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/2 pointer-events-none mix-blend-screen"></div>
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150 mix-blend-overlay"></div>

        <div className="relative z-10 max-w-lg mx-auto w-full">
            <h2 className="text-white/30 font-black uppercase tracking-[0.3em] mb-10 text-xs text-center">Manifeste de Campagne</h2>
            
            <div className="bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2.5rem] p-10 shadow-2xl space-y-10 transition-all duration-700 hover:border-white/20 hover:bg-white/10 group">
                
                {/* Header Manifeste */}
                <div className="flex items-center gap-4 border-b border-white/10 pb-8">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
                        <span className="text-xl">🚀</span>
                    </div>
                    <div>
                        <div className="text-[10px] font-bold text-blue-400 uppercase tracking-widest mb-1">Projet</div>
                        <div className="text-2xl font-black text-white leading-none tracking-tight">
                            {formData.sector || "Nouvelle Campagne"}
                        </div>
                    </div>
                </div>

                {/* Section Cible & Objectif */}
                <div className={`space-y-6 transition-all duration-700 delay-100 ${step >= 2 ? 'opacity-100 translate-x-0' : 'opacity-20 translate-x-4 blur-sm'}`}>
                    <div>
                         <label className="text-[10px] font-bold text-purple-400 uppercase tracking-widest mb-2 block">Cible Identifiée</label>
                         <div className="text-lg font-medium text-slate-300 leading-relaxed">
                             {formData.targetAudience ? `"${formData.targetAudience}"` : "En attente de définition..."}
                         </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                         <span className="px-3 py-1 rounded-lg bg-white/10 text-white text-xs font-bold border border-white/10">{formData.goal}</span>
                         <span className="px-3 py-1 rounded-lg bg-white/10 text-white text-xs font-bold border border-white/10">{formData.tone}</span>
                    </div>
                </div>

                {/* Section Stratégie (Timeline) */}
                <div className={`transition-all duration-700 delay-200 ${step >= 3 ? 'opacity-100 translate-y-0' : 'opacity-20 translate-y-4 blur-sm'}`}>
                    <label className="text-[10px] font-bold text-green-400 uppercase tracking-widest mb-4 block">Plan d'attaque</label>
                    
                    <div className="bg-slate-950/50 rounded-2xl p-5 border border-white/5 flex items-center justify-between">
                        <div>
                            <div className="text-xs text-slate-400 font-bold uppercase mb-1">Durée</div>
                            <div className="text-white font-black text-xl">{formData.duration}</div>
                        </div>
                        <div className="h-8 w-px bg-white/10"></div>
                        <div className="text-right">
                            <div className="text-xs text-slate-400 font-bold uppercase mb-1">Intensité</div>
                            <div className="text-white font-black text-xl">{formData.frequency}</div>
                        </div>
                    </div>
                </div>

                {/* Section Challenge */}
                <div className={`transition-all duration-700 delay-300 ${step >= 4 ? 'opacity-100' : 'opacity-20 blur-sm'}`}>
                    <label className="text-[10px] font-bold text-yellow-400 uppercase tracking-widest mb-2 block">Le Hook Principal</label>
                    <div className="text-sm font-medium text-slate-400 italic border-l-2 border-yellow-400/50 pl-4 py-1">
                        {formData.currentChallenge ? `"${formData.currentChallenge}"` : "..."}
                    </div>
                </div>

            </div>
            
            <div className="mt-10 text-center flex justify-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
                <span className="text-[10px] text-blue-400 font-mono tracking-widest uppercase">Onari Engine v2.5 Ready</span>
            </div>
        </div>
      </div>
    </div>
  );
};

export default NewCampaign;
