
import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import { User, Campaign } from '../types';

interface SidebarProps {
  user: User;
  campaigns: Campaign[];
  logout: () => void;
  onConnect: () => void;
  onDisconnect: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ user, campaigns, logout, onConnect, onDisconnect }) => {
  const location = useLocation();
  
  const [isMarketingOpen, setIsMarketingOpen] = useState(true);
  const [isDataOpen, setIsDataOpen] = useState(true);

  useEffect(() => {
    const marketingPaths = ['/studio', '/planning', '/campaign/new', '/campaign/results'];
    const dataPaths = ['/analytics', '/competition', '/crm'];
    
    if (marketingPaths.some(path => location.pathname.includes(path))) {
      setIsMarketingOpen(true);
    } else if (dataPaths.some(path => location.pathname.includes(path))) {
      setIsDataOpen(true);
    }
  }, [location.pathname]);

  return (
    <aside className="w-64 bg-slate-950 text-slate-300 hidden md:flex flex-col flex-shrink-0 border-r border-slate-800 h-screen sticky top-0 z-20 shadow-xl">
      <div className="h-16 flex items-center px-6 border-b border-slate-800/50">
        <Link to="/dashboard" className="text-lg font-semibold text-white flex items-center gap-2 tracking-tight">
          <div className="w-6 h-6 bg-blue-600 rounded-md flex items-center justify-center">
             <span className="text-xs font-bold text-white">L</span>
          </div>
          LinkBoost AI
        </Link>
      </div>

      <nav className="flex-1 px-3 py-6 overflow-y-auto custom-scrollbar space-y-6">
        
        {/* DASHBOARD */}
        <div>
           <NavLink 
              to="/dashboard" 
              className={({isActive}) => `flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-all duration-200 ${
                isActive 
                ? 'bg-blue-600/10 text-blue-400 border-l-2 border-blue-500' 
                : 'hover:bg-slate-900 text-slate-400 hover:text-slate-200 border-l-2 border-transparent'
              }`}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
              Tableau de bord
            </NavLink>
        </div>

        {/* --- GROUPE AGENT MARKETING --- */}
        <div>
          <button 
            onClick={() => setIsMarketingOpen(!isMarketingOpen)}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-md text-sm font-medium transition-all duration-200 hover:bg-slate-900 ${isMarketingOpen ? 'text-white' : 'text-slate-400'}`}
          >
            <div className="flex items-center gap-3">
              <svg className="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"/></svg>
              Agent Marketing
            </div>
            <svg className={`w-3 h-3 transition-transform duration-200 ${isMarketingOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"/></svg>
          </button>

          <div className={`mt-1 space-y-1 overflow-hidden transition-all duration-300 ${isMarketingOpen ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'}`}>
             <NavLink 
                to="/studio" 
                className={({isActive}) => `flex items-center gap-3 pl-10 pr-3 py-2 rounded-md text-xs font-medium transition-all ${
                  isActive ? 'text-blue-400 bg-slate-900' : 'text-slate-500 hover:text-slate-300'
                }`}
             >
                <span className="w-1.5 h-1.5 rounded-full bg-current opacity-50"></span>
                Création de post (IA)
             </NavLink>
             <NavLink 
                to="/planning" 
                className={({isActive}) => `flex items-center gap-3 pl-10 pr-3 py-2 rounded-md text-xs font-medium transition-all ${
                  isActive ? 'text-blue-400 bg-slate-900' : 'text-slate-500 hover:text-slate-300'
                }`}
             >
                <span className="w-1.5 h-1.5 rounded-full bg-current opacity-50"></span>
                Planification
             </NavLink>
             <NavLink 
                to="/campaign/new" 
                className={({isActive}) => `flex items-center gap-3 pl-10 pr-3 py-2 rounded-md text-xs font-medium transition-all ${
                  isActive ? 'text-blue-400 bg-slate-900' : 'text-slate-500 hover:text-slate-300'
                }`}
             >
                <span className="w-1.5 h-1.5 rounded-full bg-current opacity-50"></span>
                Nouvelle campagne
             </NavLink>
          </div>
        </div>

        {/* --- GROUPE AGENT DATA --- */}
        <div>
          <button 
            onClick={() => setIsDataOpen(!isDataOpen)}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-md text-sm font-medium transition-all duration-200 hover:bg-slate-900 ${isDataOpen ? 'text-white' : 'text-slate-400'}`}
          >
            <div className="flex items-center gap-3">
              <svg className="w-4 h-4 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
              Agent Data
            </div>
            <svg className={`w-3 h-3 transition-transform duration-200 ${isDataOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"/></svg>
          </button>

          <div className={`mt-1 space-y-1 overflow-hidden transition-all duration-300 ${isDataOpen ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'}`}>
             <NavLink 
                to="/analytics/content" 
                className={({isActive}) => `flex items-center gap-3 pl-10 pr-3 py-2 rounded-md text-xs font-medium transition-all ${
                  isActive || location.pathname === '/analytics/content' ? 'text-purple-400 bg-slate-900' : 'text-slate-500 hover:text-slate-300'
                }`}
             >
                <span className="w-1.5 h-1.5 rounded-full bg-current opacity-50"></span>
                Analyse des Posts
             </NavLink>
             <NavLink 
                to="/analytics/competitors" 
                className={({isActive}) => `flex items-center gap-3 pl-10 pr-3 py-2 rounded-md text-xs font-medium transition-all ${
                  isActive || location.pathname === '/analytics/competitors' ? 'text-purple-400 bg-slate-900' : 'text-slate-500 hover:text-slate-300'
                }`}
             >
                <span className="w-1.5 h-1.5 rounded-full bg-current opacity-50"></span>
                Veille Concurrents
             </NavLink>
          </div>
        </div>

        {/* LIENS RÉCENTS */}
        {campaigns.length > 0 && (
          <div className="pt-4 border-t border-slate-800">
            <p className="px-3 text-[10px] font-semibold uppercase tracking-wider text-slate-600 mb-2">Comptes liés</p>
            <div className="space-y-1">
              {campaigns.slice(0, 3).map((camp) => (
                <Link 
                  key={camp.id} 
                  to={`/campaign/results/${camp.id}`}
                  className={`flex items-center gap-2 px-3 py-2 rounded-md hover:bg-slate-900 transition-all ${location.pathname.includes(camp.id) ? 'bg-slate-900 text-slate-200' : 'text-slate-400'}`}
                >
                  <div className="w-2 h-2 rounded-full bg-green-500"></div>
                  <span className="text-xs truncate font-medium">{camp.linkedinUrl.split('/in/')[1] || camp.linkedinUrl}</span>
                </Link>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* FOOTER USER / CONNEXION LINKEDIN */}
      <div className="p-4 border-t border-slate-800 bg-slate-950">
        
        {/* État de connexion LinkedIn */}
        <div className="mb-4">
            {user.linkedInConnected ? (
                <div className="flex items-center gap-3 bg-slate-900 p-2 rounded-lg border border-slate-800">
                     <div className="relative">
                        {user.linkedInProfile?.avatar ? (
                            <img src={user.linkedInProfile.avatar} alt="Avatar" className="w-8 h-8 rounded-full object-cover" />
                        ) : (
                            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-xs font-bold text-white">
                                {user.name.charAt(0)}
                            </div>
                        )}
                        <span className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-slate-900 rounded-full"></span>
                     </div>
                     <div className="flex-1 min-w-0">
                         <p className="text-xs font-bold text-white truncate">{user.name}</p>
                         <p className="text-[10px] text-green-400">Compte Connecté</p>
                     </div>
                     <button onClick={onDisconnect} className="text-slate-500 hover:text-red-400" title="Déconnecter">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                     </button>
                </div>
            ) : (
                <button 
                    onClick={onConnect}
                    className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-900/20"
                >
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                    Connecter LinkedIn
                </button>
            )}
        </div>

        {/* --- NOUVEAU BOUTON PARAMÈTRES --- */}
        <NavLink 
            to="/settings"
            className={({isActive}) => `w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium rounded-md transition-colors mb-2 ${
                isActive ? 'text-white bg-slate-900' : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
        >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            Paramètres
        </NavLink>

        <button onClick={logout} className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-900 rounded-md transition-colors">
          Déconnexion
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
