
import React, { useState, useRef } from 'react';
import { Campaign, SocialMediaPost, ContentIdea } from '../types';
import { refinePostWithAI, streamPostContent } from '../services/geminiService';

interface StudioProps {
  campaigns: Campaign[];
  onUpdate: (c: Campaign) => void;
}

const Studio: React.FC<StudioProps> = ({ campaigns, onUpdate }) => {
  const [selectedCampaignId, setSelectedCampaignId] = useState(campaigns[0]?.id || '');
  const campaign = campaigns.find(c => c.id === selectedCampaignId);
  const [schedulingPost, setSchedulingPost] = useState<string | null>(null);
  
  // États d'édition
  const [editingPostId, setEditingPostId] = useState<string | null>(null);
  const [editedPost, setEditedPost] = useState<SocialMediaPost | null>(null);
  const [editorAiInput, setEditorAiInput] = useState('');
  const [isAiRefining, setIsAiRefining] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const mockIdeas: ContentIdea[] = [
    { id: '1', title: "L'avenir de la déconstruction sélective", angle: "Éducatif", potential: "High" },
    { id: '2', title: "Comment j'ai sauvé 30% de budget", angle: "Cas Client", potential: "Viral" },
    { id: '3', title: "3 erreurs fatales en architecture", angle: "Conseil", potential: "Medium" },
  ];

  // Logic Handlers
  const handleSchedule = (postId: string, date: string) => {
    if (!campaign || !campaign.result) return;
    const updatedPosts = campaign.result.posts.map(p => p.id === postId ? { ...p, scheduledDate: date, status: 'scheduled' as const } : p);
    onUpdate({ ...campaign, result: { ...campaign.result, posts: updatedPosts } });
    setSchedulingPost(null);
  };

  const handleEditClick = (post: SocialMediaPost) => { setEditedPost({ ...post }); setEditingPostId(post.id); setEditorAiInput(''); setIsAiRefining(false); };
  const handleCreatePost = () => {
    const newPost: SocialMediaPost = { id: `new_${Date.now()}`, plateforme: 'LinkedIn', status: 'draft', type: 'Nouveau', hook: "Nouvelle idée...", body: "", hashtags: [], conseil_visuel: "" };
    if (campaign && campaign.result) onUpdate({ ...campaign, result: { ...campaign.result, posts: [newPost, ...campaign.result.posts] } });
    handleEditClick(newPost);
  };
  const handleSavePost = () => { if (campaign && campaign.result && editedPost) { onUpdate({ ...campaign, result: { ...campaign.result, posts: campaign.result.posts.map(p => p.id === editedPost.id ? editedPost : p) } }); } setEditingPostId(null); setEditedPost(null); };
  const handleDeletePost = () => { if (campaign && campaign.result && editingPostId) { onUpdate({ ...campaign, result: { ...campaign.result, posts: campaign.result.posts.filter(p => p.id !== editingPostId) } }); } setEditingPostId(null); setEditedPost(null); };
  
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && editedPost) {
        const reader = new FileReader();
        reader.onloadend = () => {
            setEditedPost({
                ...editedPost,
                mediaUrl: reader.result as string,
                mediaType: file.type.startsWith('video') ? 'video' : 'image'
            });
        };
        reader.readAsDataURL(file);
    }
  };

  const handleAiRefine = async (postToEdit = editedPost, input = editorAiInput) => {
    if (!input.trim() || !postToEdit || !campaign) return;
    setIsAiRefining(true); setEditorAiInput(input);
    abortControllerRef.current = new AbortController();
    try {
      const isStructureChange = input.toLowerCase().includes('hook') || input.toLowerCase().includes('tag');
      if (isStructureChange) {
        const refined = await refinePostWithAI(postToEdit, input, campaign);
        setEditedPost(prev => prev ? { ...prev, hook: refined.hook || prev.hook, body: refined.body, hashtags: refined.hashtags?.length > 0 ? refined.hashtags : prev.hashtags } : null);
      } else {
        if (input.toLowerCase().includes('écris') || input.toLowerCase().includes('génère')) setEditedPost(prev => prev ? { ...prev, body: '' } : null);
        await streamPostContent(postToEdit, input, campaign, (chunk) => { if (!isAiRefining && !abortControllerRef.current) return; setEditedPost(prev => prev ? { ...prev, body: prev.body + chunk } : null); });
      }
      setEditorAiInput('');
    } catch (e) { console.error(e); } finally { setIsAiRefining(false); abortControllerRef.current = null; }
  };
  const stopGeneration = () => { if (abortControllerRef.current) { abortControllerRef.current.abort(); abortControllerRef.current = null; } setIsAiRefining(false); };

  if (!campaign) return <div className="p-20 text-center text-slate-400">Aucune campagne active.</div>;

  return (
    <div className="h-full flex flex-col md:flex-row bg-slate-50 overflow-hidden">
        
        {/* MAIN CONTENT - LISTE DES POSTS */}
        <div className="flex-1 flex flex-col min-w-0">
            <header className="px-8 py-6 bg-white border-b border-slate-200 flex justify-between items-center">
                <div>
                    <h1 className="text-xl font-bold text-slate-900">Studio de Création</h1>
                    <div className="flex items-center gap-2 mt-1">
                        <select value={selectedCampaignId} onChange={(e) => setSelectedCampaignId(e.target.value)} className="text-sm border-none p-0 font-medium text-slate-600 bg-transparent outline-none focus:ring-0 cursor-pointer hover:text-blue-600">
                            {campaigns.map(c => <option key={c.id} value={c.id}>{c.sector} - {c.linkedinUrl}</option>)}
                        </select>
                    </div>
                </div>
                <button onClick={handleCreatePost} className="px-4 py-2 bg-blue-600 text-white text-sm font-semibold rounded-lg hover:bg-blue-700 shadow-sm flex items-center gap-2">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"/></svg>
                    Nouveau Post
                </button>
            </header>

            <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                <div className="max-w-4xl mx-auto space-y-4">
                    {campaign.result?.posts.map((post, idx) => (
                        <div key={post.id || idx} className="bg-white rounded-lg border border-slate-200 hover:border-blue-300 shadow-sm transition-all group">
                            <div className="p-5 flex gap-4">
                                <div className="flex-shrink-0 w-10 h-10 bg-slate-100 rounded-md flex items-center justify-center text-slate-500 text-sm font-bold overflow-hidden">
                                    {post.mediaUrl ? (
                                        post.mediaType === 'video' ? '🎥' : <img src={post.mediaUrl} className="w-full h-full object-cover" />
                                    ) : (
                                        idx + 1
                                    )}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2 mb-1">
                                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                                            post.status === 'scheduled' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'
                                        }`}>
                                            {post.status === 'scheduled' ? 'Planifié' : 'Brouillon'}
                                        </span>
                                        <span className="text-xs text-slate-400 font-medium">{post.type}</span>
                                    </div>
                                    <h3 className="text-lg font-bold text-slate-800 mb-2 truncate">{post.hook || "Sans titre"}</h3>
                                    <p className="text-slate-600 text-sm line-clamp-2 leading-relaxed mb-3">{post.body}</p>
                                    
                                    <div className="flex items-center gap-2 border-t border-slate-100 pt-3">
                                        <button onClick={() => handleEditClick(post)} className="text-sm font-medium text-slate-500 hover:text-blue-600 transition-colors">Éditer le contenu</button>
                                        <div className="w-px h-3 bg-slate-200"></div>
                                        {post.status === 'scheduled' ? (
                                            <span className="text-sm text-green-600 font-medium flex items-center gap-1">
                                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                                {new Date(post.scheduledDate!).toLocaleDateString()}
                                            </span>
                                        ) : (
                                            <button onClick={() => setSchedulingPost(post.id)} className="text-sm font-medium text-slate-500 hover:text-blue-600 transition-colors">Programmer</button>
                                        )}
                                    </div>
                                    
                                    {schedulingPost === post.id && (
                                        <div className="mt-3 p-3 bg-slate-50 rounded-lg flex gap-2 animate-in slide-in-from-top-2">
                                            <input type="date" className="text-sm border border-slate-300 rounded px-2 py-1" onChange={(e) => handleSchedule(post.id, e.target.value)} />
                                            <button onClick={() => setSchedulingPost(null)} className="text-sm text-slate-500 hover:text-slate-800">Annuler</button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>

        {/* SIDEBAR RIGHT - IDEAS */}
        <aside className="w-80 bg-white border-l border-slate-200 hidden xl:flex flex-col">
            <div className="p-6 border-b border-slate-200 bg-slate-50">
                <h3 className="font-bold text-slate-800 flex items-center gap-2">
                    <span className="text-lg">💡</span> Idées IA
                </h3>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {mockIdeas.map(idea => (
                    <div key={idea.id} className="p-4 rounded-lg border border-slate-200 hover:border-blue-400 hover:shadow-sm cursor-pointer transition-all bg-white group">
                        <div className="flex justify-between items-start mb-2">
                            <span className="text-[10px] font-bold uppercase text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">{idea.angle}</span>
                            <span className={`w-2 h-2 rounded-full ${idea.potential === 'Viral' ? 'bg-red-500' : 'bg-blue-500'}`}></span>
                        </div>
                        <p className="font-semibold text-sm text-slate-800 mb-3">{idea.title}</p>
                        <button className="text-xs font-medium text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity">
                            Générer →
                        </button>
                    </div>
                ))}
            </div>
        </aside>

        {/* MODAL EDIT (Full Screen Overlay Professional) */}
        {editingPostId && editedPost && (
            <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-white w-full max-w-5xl h-[85vh] rounded-xl shadow-2xl flex overflow-hidden">
                    {/* Colonne Edition */}
                    <div className="flex-1 flex flex-col border-r border-slate-200">
                        <div className="px-6 py-4 border-b border-slate-200 flex justify-between items-center bg-slate-50">
                            <h3 className="font-bold text-slate-800">Éditeur</h3>
                            <div className="flex gap-2">
                                <button onClick={handleDeletePost} className="text-red-500 hover:bg-red-50 p-2 rounded-md"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg></button>
                            </div>
                        </div>
                        <div className="flex-1 overflow-y-auto p-8 space-y-6">
                            
                            {/* ZONE MEDIA */}
                            <div className="mb-4">
                                <input 
                                    type="file" 
                                    accept="image/*,video/*" 
                                    className="hidden" 
                                    ref={fileInputRef}
                                    onChange={handleFileSelect}
                                />
                                <div 
                                    onClick={() => fileInputRef.current?.click()}
                                    className="w-full h-40 border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:bg-slate-50 hover:border-blue-400 transition-all overflow-hidden relative group"
                                >
                                    {editedPost.mediaUrl ? (
                                        editedPost.mediaType === 'video' ? (
                                            <video src={editedPost.mediaUrl} className="w-full h-full object-cover" controls />
                                        ) : (
                                            <img src={editedPost.mediaUrl} alt="Post media" className="w-full h-full object-cover" />
                                        )
                                    ) : (
                                        <div className="flex flex-col items-center text-slate-400">
                                            <svg className="w-8 h-8 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                            <span className="text-xs font-bold uppercase">Ajouter Média</span>
                                        </div>
                                    )}
                                    {editedPost.mediaUrl && (
                                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                            <span className="text-white text-xs font-bold">Changer le média</span>
                                        </div>
                                    )}
                                </div>
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Accroche</label>
                                <textarea 
                                    value={editedPost.hook} onChange={e => setEditedPost({...editedPost, hook: e.target.value})}
                                    className="w-full text-xl font-bold text-slate-900 border-none p-0 focus:ring-0 resize-none placeholder:text-slate-300"
                                    rows={2} placeholder="Votre titre percutant..."
                                />
                            </div>
                            <div className="h-px bg-slate-100 w-full"></div>
                            <div className="flex-1">
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Contenu</label>
                                <textarea 
                                    value={editedPost.body} onChange={e => setEditedPost({...editedPost, body: e.target.value})}
                                    className="w-full h-96 text-base text-slate-700 leading-relaxed border-none p-0 focus:ring-0 resize-none placeholder:text-slate-300"
                                    placeholder="Commencez à écrire..."
                                />
                            </div>
                        </div>
                        <div className="px-6 py-4 border-t border-slate-200 flex justify-end gap-3 bg-slate-50">
                            <button onClick={() => { setEditingPostId(null); setEditedPost(null); }} className="px-4 py-2 text-slate-600 font-medium hover:text-slate-900">Annuler</button>
                            <button onClick={handleSavePost} className="px-6 py-2 bg-slate-900 text-white font-semibold rounded-lg hover:bg-slate-800">Enregistrer</button>
                        </div>
                    </div>

                    {/* Colonne IA */}
                    <div className="w-80 bg-slate-50 flex flex-col">
                        <div className="px-6 py-4 border-b border-slate-200">
                            <h3 className="font-bold text-slate-700 text-sm uppercase">Assistant IA</h3>
                        </div>
                        <div className="flex-1 p-6 flex flex-col">
                            <div className="flex-1 space-y-2 overflow-y-auto mb-4">
                                <p className="text-xs text-slate-500 font-medium mb-2">Suggestions rapides :</p>
                                {["Raccourcir le texte", "Rendre plus professionnel", "Ajouter une touche d'humour", "Vérifier l'orthographe"].map(opt => (
                                    <button key={opt} onClick={() => setEditorAiInput(opt)} className="w-full text-left px-3 py-2 bg-white border border-slate-200 rounded-md text-xs font-medium text-slate-700 hover:border-blue-400 transition-colors">
                                        {opt}
                                    </button>
                                ))}
                            </div>
                            
                            <div className="mt-auto">
                                <label className="block text-xs font-bold text-slate-500 mb-2">Instruction personnalisée</label>
                                <div className="relative">
                                    <textarea 
                                        value={editorAiInput} onChange={e => setEditorAiInput(e.target.value)}
                                        className="w-full rounded-lg border-slate-300 text-sm focus:border-blue-500 focus:ring-blue-500 min-h-[80px]"
                                        placeholder="Ex: Réécris l'intro..."
                                    />
                                    <button 
                                        onClick={() => handleAiRefine(editedPost, editorAiInput)}
                                        disabled={isAiRefining || !editorAiInput.trim()}
                                        className="absolute bottom-2 right-2 p-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                                    >
                                        {isAiRefining ? <span className="block w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span> : "Go"}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default Studio;
