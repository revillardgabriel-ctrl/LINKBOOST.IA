
import { Campaign, MarketingStrategy, AnalysisEngine } from "../types";
import { generateLinkedInStrategy } from "./geminiService";

export const campaignService = {
  async processCampaign(campaignData: any): Promise<MarketingStrategy> {
    const engine = localStorage.getItem('analysis_engine') || AnalysisEngine.INTERNAL;

    if (engine === AnalysisEngine.INTERNAL) {
      return await generateLinkedInStrategy(
        campaignData.linkedinUrl,
        campaignData.goal,
        campaignData.sector,
        campaignData.tone,
        campaignData.targetAudience,
        campaignData.currentChallenge
      );
    } else {
      return await this.processWithN8N(campaignData);
    }
  },

  async processWithN8N(campaignData: any): Promise<MarketingStrategy> {
    const webhookUrl = localStorage.getItem('n8n_webhook_url');
    const apiKey = localStorage.getItem('n8n_api_key') || '';

    if (!webhookUrl) throw new Error("URL n8n non configurée.");

    try {
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        mode: 'cors',
        body: JSON.stringify(campaignData),
      });

      if (!response.ok) throw new Error("Erreur serveur n8n");
      return await response.json();
    } catch (error) {
      return await generateLinkedInStrategy(
        campaignData.linkedinUrl,
        campaignData.goal,
        campaignData.sector,
        campaignData.tone,
        campaignData.targetAudience,
        campaignData.currentChallenge
      );
    }
  },

  getEngine(): AnalysisEngine {
    return (localStorage.getItem('analysis_engine') as AnalysisEngine) || AnalysisEngine.INTERNAL;
  },

  setEngine(engine: AnalysisEngine) {
    localStorage.setItem('analysis_engine', engine);
  }
};
