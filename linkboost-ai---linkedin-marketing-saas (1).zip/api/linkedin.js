
export default async function handler(req, res) {
  // CONFIGURATION VERCEL :
  // Assurez-vous d'avoir ajouté VITE_LINKEDIN_CLIENT_ID et LINKEDIN_CLIENT_SECRET 
  // dans les Environment Variables de votre projet Vercel.

  const CLIENT_ID = process.env.VITE_LINKEDIN_CLIENT_ID;
  const CLIENT_SECRET = process.env.LINKEDIN_CLIENT_SECRET;
  
  // On récupère l'URI envoyée par le frontend pour être sûr qu'elle correspond exactement
  // à celle utilisée lors de la demande du code (avec ou sans le #).
  const { code, redirect_uri } = req.body;

  // Fallback si le frontend ne l'envoie pas (pour compatibilité)
  const REDIRECT_URI = redirect_uri || (req.headers.origin + '/auth/callback');

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  if (!code) {
    return res.status(400).json({ error: 'Code manquant' });
  }

  try {
    // 2. Échange du code contre un Access Token
    const tokenResponse = await fetch('https://www.linkedin.com/oauth/v2/accessToken', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code: code,
        redirect_uri: REDIRECT_URI,
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
      }),
    });

    const tokenData = await tokenResponse.json();

    if (tokenData.error) {
      console.error("LinkedIn Token Error:", tokenData);
      throw new Error(tokenData.error_description || 'Erreur lors de l\'échange du token LinkedIn');
    }

    const accessToken = tokenData.access_token;

    // 3. Récupération du profil utilisateur avec le token
    const profileResponse = await fetch('https://api.linkedin.com/v2/me', {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!profileResponse.ok) {
        throw new Error("Impossible de récupérer le profil utilisateur.");
    }

    const profileData = await profileResponse.json();

    // 4. (Optionnel) Récupération de l'email si le scope r_emailaddress est activé
    // Pour l'instant on se contente du profil Lite

    return res.status(200).json({
      success: true,
      user: {
        id: profileData.id,
        firstName: profileData.localizedFirstName,
        lastName: profileData.localizedLastName,
        // Simulation avatar car l'API Image V2 est complexe sans permission supplémentaire
        avatar: `https://ui-avatars.com/api/?name=${profileData.localizedFirstName}+${profileData.localizedLastName}&background=0D8ABC&color=fff`
      }
    });

  } catch (error) {
    console.error("Serverless Function Error:", error);
    return res.status(500).json({ error: error.message });
  }
}
