
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import NewCampaign from './components/NewCampaign';
import Results from './components/Results';
import Studio from './components/Studio';
import Planning from './components/Planning';
import Admin from './components/Admin';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import Onboarding from './components/Onboarding';
import Analytics from './components/Analytics';
import PrivacyPolicy from './components/PrivacyPolicy';
import Settings from './components/Settings';
import LinkedInConnectModal from './components/LinkedInConnectModal';
import LinkedInCallback from './components/LinkedInCallback'; // Import
import { User, Campaign, LinkedInProfile, CampaignTone, MarketingStrategy } from './types';

// Composant Placeholder pour les pages en construction
const ComingSoon = ({ title }: { title: string }) => (
  <div className="flex flex-col items-center justify-center h-full p-10 text-center">
    <div className="text-6xl mb-4">🚧</div>
    <h2 className="text-3xl font-black text-slate-900 mb-2">Agent {title}</h2>
    <p className="text-slate-500">Module en cours de développement par l'équipe Onari.</p>
  </div>
);

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [showConnectModal, setShowConnectModal] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem('onari_user');
    const savedCampaigns = localStorage.getItem('onari_campaigns');

    if (savedUser) {
      setUser(JSON.parse(savedUser));
      if (savedCampaigns) setCampaigns(JSON.parse(savedCampaigns));
    } else {
      const demoUser: User = {
        id: 'demo_user',
        email: 'demo@onari.ai',
        name: 'Architecte Demo',
        credits: 50,
        role: 'admin',
        linkedInConnected: false,
      };
      
      const demoResult: MarketingStrategy = {
        strategie_du_jour: "Positionnement Expert Technique et Humain",
        optimizationScore: 85,
        profileAnalysis: {
            strengths: ["Expertise technique visible", "Bonne photo de profil"],
            weaknesses: ["Manque de régularité", "Pas assez de storytelling"],
            opportunities: ["Parler des coulisses chantier", "Vidéos time-lapse"]
        },
        posts: [
            {
                id: "post_demo_1",
                plateforme: "LinkedIn",
                status: "draft",
                type: "Storytelling",
                hook: "48 heures pour tout curer avant l'arrivée du second œuvre.",
                body: "Le timing était serré. Un plateau de 400m2, des cloisons amiantées et un accès restreint.\n\nPour un architecte, c'est le scénario catastrophe. Notre mission : libérer l'espace sans compromettre la structure ni la sécurité du bâtiment.\n\nRésultat ? Un chantier livré avec 4h d'avance, balayé et prêt à reconstruire.\n\nLa démolition n'est pas qu'une question de force, c'est une question de logistique millimétrée.\n\nBesoin d'un partenaire qui respecte vos plannings ? Discutons de votre prochain projet en MP.",
                hashtags: ["#Demolition", "#ArchitectureInterieure", "#GestionDeChantier"],
                conseil_visuel: "Photo avant/après du plateau curé, prise grand angle."
            },
            {
                id: "post_demo_2",
                plateforme: "LinkedIn",
                status: "draft",
                type: "Autorité",
                hook: "Démolition intérieure : Pourquoi la précision bat la force brute ?",
                body: "Beaucoup voient notre métier comme destructeur. C'est l'inverse. Dans la rénovation, nous sommes les chirurgiens du bâtiment.\n\nPréserver les réseaux existants, trier les déchets à la source, sécuriser la structure porteuse.\n\nUne erreur de jugement à cette étape coûte des milliers d'euros en reconstruction.\n\nNe confiez pas vos clés à n'importe qui.",
                hashtags: ["#BTP", "#Expertise", "#Renovation"],
                conseil_visuel: "Zoom sur un détail technique ou un outil de précision."
            }
        ],
        planning: "Mardi 8h30, Jeudi 11h00"
      };

      const demoCampaign: Campaign = {
        id: 'demo_campaign_1',
        linkedinUrl: 'https://linkedin.com/in/demo-architecte',
        goal: 'Visibilité B2B',
        sector: 'BTP & Architecture',
        tone: CampaignTone.PROFESSIONAL,
        targetAudience: 'Architectes et Maîtres d\'œuvre',
        currentChallenge: 'Manque de temps pour poster',
        createdAt: new Date().toISOString(),
        status: 'completed',
        result: demoResult
      };

      setUser(demoUser);
      setCampaigns([demoCampaign]);
      localStorage.setItem('onari_user', JSON.stringify(demoUser));
      localStorage.setItem('onari_campaigns', JSON.stringify([demoCampaign]));
    }
  }, []);

  const login = (userData: User) => {
    setUser(userData);
    localStorage.setItem('onari_user', JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    setCampaigns([]);
    localStorage.removeItem('onari_user');
    localStorage.removeItem('onari_campaigns');
    window.location.hash = '#/';
  };

  const connectLinkedIn = (profile: LinkedInProfile) => {
    if (!user) return;
    const updatedUser: User = { 
        ...user, 
        name: profile.name,
        linkedInConnected: true, 
        linkedInProfile: profile 
    };
    setUser(updatedUser);
    localStorage.setItem('onari_user', JSON.stringify(updatedUser));
    setShowConnectModal(false);
  };

  const disconnectLinkedIn = () => {
    if (!user) return;
    const updatedUser = { ...user, linkedInConnected: false, linkedInProfile: undefined };
    setUser(updatedUser);
    localStorage.setItem('onari_user', JSON.stringify(updatedUser));
  };

  const addCampaign = (campaign: Campaign) => {
    setCampaigns(prev => {
      const filtered = prev.filter(c => c.id !== campaign.id);
      const newCampaigns = [campaign, ...filtered];
      localStorage.setItem('onari_campaigns', JSON.stringify(newCampaigns));
      return newCampaigns;
    });
    
    if (user && campaign.status === 'completed' && !campaigns.find(c => c.id === campaign.id)) {
      const updatedUser = { ...user, credits: Math.max(0, user.credits - 1) };
      setUser(updatedUser);
      localStorage.setItem('onari_user', JSON.stringify(updatedUser));
    }
  };

  const updateCampaign = (updatedCampaign: Campaign) => {
    setCampaigns(prev => {
      const newCampaigns = prev.map(c => c.id === updatedCampaign.id ? updatedCampaign : c);
      localStorage.setItem('onari_campaigns', JSON.stringify(newCampaigns));
      return newCampaigns;
    });
  };

  const InitialRedirect = () => {
    if (user && campaigns.length > 0) {
        return <Navigate to={`/campaign/results/${campaigns[0].id}`} />;
    }
    return user ? <Navigate to="/dashboard" /> : <LandingPage login={login} />;
  }

  return (
    <HashRouter>
      <div className="min-h-screen flex bg-slate-50 font-sans">
        {user && campaigns.length > 0 && !window.location.hash.includes('onboarding') && !window.location.hash.includes('auth/callback') && (
          <Sidebar 
            user={user} 
            campaigns={campaigns}
            logout={logout} 
            onConnect={() => setShowConnectModal(true)} 
            onDisconnect={disconnectLinkedIn} 
          />
        )}
        
        <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
          {user && campaigns.length > 0 && !window.location.hash.includes('onboarding') && !window.location.hash.includes('auth/callback') && (
            <Navbar user={user} login={login} logout={logout} />
          )}
          
          <main className="flex-1 overflow-y-auto bg-slate-50 relative">
            <Routes>
              <Route path="/" element={<InitialRedirect />} />
              <Route path="/onboarding" element={user ? <Onboarding onComplete={addCampaign} user={user} /> : <Navigate to="/" />} />
              <Route path="/dashboard" element={user ? <Dashboard user={user} campaigns={campaigns} onConnect={() => setShowConnectModal(true)} /> : <Navigate to="/" />} />
              <Route path="/studio" element={user ? <Studio campaigns={campaigns} onUpdate={updateCampaign} /> : <Navigate to="/" />} />
              <Route path="/planning" element={user ? <Planning campaigns={campaigns} onUpdate={updateCampaign} /> : <Navigate to="/" />} />
              <Route path="/analytics" element={user ? <Analytics campaigns={campaigns} /> : <Navigate to="/" />} />
              <Route path="/analytics/:tab" element={user ? <Analytics campaigns={campaigns} /> : <Navigate to="/" />} />
              <Route path="/campaign/new" element={user ? <NewCampaign onAdd={addCampaign} user={user} /> : <Navigate to="/" />} />
              <Route path="/campaign/results/:id" element={user ? <Results campaigns={campaigns} updateCampaign={updateCampaign} /> : <Navigate to="/" />} />
              <Route path="/admin" element={user?.role === 'admin' ? <Admin /> : <Navigate to="/" />} />
              <Route path="/privacy" element={<PrivacyPolicy />} />
              <Route path="/settings" element={user ? <Settings user={user} onDisconnect={disconnectLinkedIn} /> : <Navigate to="/" />} />
              
              {/* Route de retour LinkedIn */}
              <Route path="/auth/callback" element={<LinkedInCallback onConnect={connectLinkedIn} />} />
              
              <Route path="/crm" element={<ComingSoon title="Prospect" />} />
            </Routes>
          </main>
        </div>
      </div>

      {showConnectModal && (
        <LinkedInConnectModal 
          onClose={() => setShowConnectModal(false)} 
          onConnect={connectLinkedIn} 
        />
      )}

    </HashRouter>
  );
};

export default App;
