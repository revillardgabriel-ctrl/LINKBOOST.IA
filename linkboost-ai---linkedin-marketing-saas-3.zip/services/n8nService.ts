
import { Campaign, MarketingStrategy } from "../types";
import { generateLinkedInStrategy } from "./geminiService";

/**
 * Service pour communiquer avec les workflows n8n de manière sécurisée
 */
export const n8nService = {
  /**
   * Envoie les données de la campagne à n8n avec authentification par clé API
   */
  async processCampaign(campaignData: any): Promise<MarketingStrategy> {
    const webhookUrl = localStorage.getItem('n8n_webhook_url');
    const apiKey = localStorage.getItem('n8n_api_key') || '';

    // Si aucune URL n'est configurée ou si c'est le placeholder, on bascule sur l'IA directe pour la démo
    if (!webhookUrl || webhookUrl.includes('votre-instance-n8n.com')) {
      console.warn("Webhook n8n non configuré. Utilisation du moteur IA direct (Gemini) pour la démo.");
      return await generateLinkedInStrategy(
        campaignData.linkedinUrl,
        campaignData.goal,
        campaignData.sector,
        campaignData.tone
      );
    }
    
    try {
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
          'X-LinkBoost-Source': 'SaaS-Platform'
        },
        // 'cors' est le mode par défaut pour les requêtes cross-origin
        mode: 'cors',
        body: JSON.stringify({
          ...campaignData,
          timestamp: new Date().toISOString(),
        }),
      });

      if (response.status === 401 || response.status === 403) {
        throw new Error("Clé API n8n invalide ou refusée (Erreur 401/403).");
      }

      if (!response.ok) {
        throw new Error(`Le serveur n8n a répondu avec une erreur : ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      return data as MarketingStrategy;
    } catch (error: any) {
      console.error("Erreur détaillée n8n:", error);
      
      // Gestion spécifique du "Failed to fetch" qui est souvent lié au CORS
      if (error.message === "Failed to fetch" || error.name === "TypeError") {
        throw new Error(
          "Impossible de contacter n8n. Cela est probablement dû à un problème de CORS ou à une URL incorrecte. " +
          "Vérifiez que votre instance n8n autorise les requêtes provenant de ce domaine."
        );
      }
      
      throw error;
    }
  },

  setWebhookUrl(url: string) {
    localStorage.setItem('n8n_webhook_url', url);
  },

  getWebhookUrl(): string {
    return localStorage.getItem('n8n_webhook_url') || '';
  },

  setApiKey(key: string) {
    localStorage.setItem('n8n_api_key', key);
  },

  getApiKey(): string {
    return localStorage.getItem('n8n_api_key') || '';
  },
  
  generateRandomKey(): string {
    return Array.from(crypto.getRandomValues(new Uint8Array(24)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }
};
