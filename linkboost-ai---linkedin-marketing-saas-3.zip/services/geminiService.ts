
import { GoogleGenAI } from "@google/genai";
import { MarketingStrategy, CampaignTone, Campaign, ChatMessage, SocialMediaPost, AnalyticsReport } from "../types";

export const generateLinkedInStrategy = async (
  linkedinUrl: string,
  goal: string,
  sector: string,
  tone: CampaignTone,
  targetAudience?: string,
  currentChallenge?: string
): Promise<MarketingStrategy> => {
  if (!process.env.API_KEY) {
    throw new Error("Clé API non configurée. Vérifiez que votre environnement dispose de process.env.API_KEY.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  // On récupère le contexte concaténé (Challenge + Durée + Fréquence)
  const contextDetails = currentChallenge || "";
  
  const systemInstruction = `
    Tu es l'Architecte de Campagne Senior de l'écosystème Onari.
    Tu ne crées pas juste du contenu, tu crées une SÉQUENCE logique de persuasion.
    
    Ton objectif : Générer une campagne marketing LinkedIn complète en format JSON.

    RÈGLES DE SÉQUENCE :
    - Les posts ne doivent pas être isolés. Ils doivent raconter une histoire ou suivre une progression.
    - Utilise des structures éprouvées (AIDA, PAS, Storytelling).
    - Varie les formats (Texte pur, Carrousel simulé par texte, Image unique).

    Exemple de progression type "Sprint" (1 semaine) :
    1. Lundi : Le Problème (Hook violent, agiter la douleur).
    2. Mardi : L'Histoire (Comment tu as vécu ça ou vu un client le vivre).
    3. Mercredi : La Solution Éducative (Valeur pure, "Comment faire").
    4. Jeudi : La Preuve (Résultat, Chiffre, Témoignage).
    5. Vendredi : L'Appel à l'action (Vente douce ou dure selon l'objectif).

    STRUCTURE JSON ATTENDUE :
    {
      "strategie_du_jour": "Une phrase percutante résumant l'angle d'attaque (ex: 'Positionnement expert via la déconstruction des mythes')",
      "optimizationScore": 85,
      "profileAnalysis": {
        "strengths": ["Point fort 1", "Point fort 2"],
        "weaknesses": ["Point faible 1", "Point faible 2"],
        "opportunities": ["Opportunité 1", "Opportunité 2"]
      },
      "posts": [
        {
          "id": "1",
          "type": "Storytelling / Autorité / Vente / Éducatif / Preuve Sociale",
          "hook": "Une première phrase courte et virale",
          "body": "Le contenu complet du post avec sauts de ligne...",
          "hashtags": ["#tag1", "#tag2"],
          "conseil_visuel": "Description précise pour l'image ou la vidéo (ex: 'Photo de chantier grand angle, saturée')",
          "scheduledDate": "Date indicative ISO (ex: pour Lundi)"
        }
      ],
      "planning": "Planning suggéré (ex: 5 posts sur 1 semaine)"
    }
    
    IMPORTANT : Génère le nombre de posts adéquat selon la demande (Sprint = ~5 posts, Marathon = ~8 posts).
    Ne réponds QUE du JSON valide, sans markdown.
  `;

  const prompt = `
    Génère une campagne LinkedIn stratégique.
    
    CONTEXTE CLIENT :
    - Profil : ${linkedinUrl}
    - Secteur : ${sector}
    - Objectif : ${goal}
    - Cible : ${targetAudience || 'Non spécifiée'}
    - Ton : ${tone}
    - STRATÉGIE & DÉTAILS (Durée, Fréquence, Angle) : ${contextDetails}
    
    Instruction : Crée une séquence narrative forte. Chaque post doit donner envie de lire le suivant.
  `;

  try {
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error("Le serveur IA ne répond pas (Timeout 30s).")), 30000)
    );

    const apiPromise = ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.75, // Un peu plus créatif pour le storytelling
        responseMimeType: "application/json"
      }
    });

    const response: any = await Promise.race([apiPromise, timeoutPromise]);
    
    const text = response.text?.trim();
    if (!text) throw new Error("Réponse vide de l'IA");

    const cleanJson = text.replace(/```json/g, '').replace(/```/g, '');

    let result;
    try {
      result = JSON.parse(cleanJson);
    } catch (parseError) {
      console.error("Erreur Parsing JSON:", text);
      throw new Error("L'IA a généré un format invalide. Veuillez réessayer.");
    }

    if (!result.posts || !Array.isArray(result.posts)) result.posts = [];
    
    // Post-traitement des dates (Simulation de planning intelligent)
    const today = new Date();
    // Si c'est un "Sprint" (détecté via le nb de posts ou le contexte), on planifie tous les jours ouvrés
    // Sinon on étale tous les 2 jours
    const isSprint = result.posts.length >= 5 && contextDetails.toLowerCase().includes('semaine');
    
    result.posts = result.posts.map((p: any, i: number) => {
        const date = new Date(today);
        if (isSprint) {
             date.setDate(today.getDate() + i + 1); // 1 jour après l'autre
        } else {
             date.setDate(today.getDate() + (i * 2) + 1); // 1 jour sur 2
        }
        
        // Fixer à 9h00 du matin par défaut
        date.setHours(9, 0, 0, 0);
        // Éviter le week-end si possible (simple check)
        if (date.getDay() === 0) date.setDate(date.getDate() + 1); // Dimanche -> Lundi
        if (date.getDay() === 6) date.setDate(date.getDate() + 2); // Samedi -> Lundi

        return {
            ...p,
            id: p.id || `post_${Date.now()}_${i}`,
            plateforme: 'LinkedIn',
            status: 'draft', 
            type: p.type || 'Standard',
            hashtags: p.hashtags || [],
            conseil_visuel: p.conseil_visuel || "Visuel professionnel en rapport avec le sujet.",
            scheduledDate: p.scheduledDate || date.toISOString()
        };
    });

    if (!result.profileAnalysis) {
      result.profileAnalysis = { strengths: [], weaknesses: [], opportunities: [] };
    }

    return result as MarketingStrategy;

  } catch (e: any) {
    console.error("Erreur Onari Engine:", e);
    if (e.message.includes("Timeout")) throw e;
    throw new Error(e.message || "Erreur de connexion à l'IA.");
  }
};

export const sendChatMessage = async (
  message: string,
  history: ChatMessage[],
  campaignContext: Campaign
): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("Clé API non configurée.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const systemInstruction = `
    Tu es l'Agent Campagne Senior de l'écosystème Onari.
    Tu discutes avec l'utilisateur pour affiner sa stratégie LinkedIn.
    
    CONTEXTE DU PROJET :
    - Secteur : ${campaignContext.sector}
    - Objectif : ${campaignContext.goal}
    - Ton : ${campaignContext.tone}
    
    MISSIONS :
    1. Aider l'utilisateur à réécrire des posts.
    2. Proposer de nouveaux thèmes.
    3. Être concis et pro.
  `;

  const chatHistory = history.slice(0, -1).map(msg => ({
    role: msg.role,
    parts: [{ text: msg.text }]
  }));

  try {
    const chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      history: chatHistory,
      config: {
        systemInstruction: systemInstruction,
      }
    });

    const result = await chat.sendMessage({ message: message });
    return result.text || "Je n'ai pas pu générer de réponse.";
  } catch (error) {
    console.error("Chat Error:", error);
    throw new Error("Erreur lors de la discussion avec l'IA.");
  }
};

// Fonction pour l'édition chirurgicale JSON (Hook, Tags, structure)
export const refinePostWithAI = async (
  currentPost: SocialMediaPost,
  instruction: string,
  campaignContext: Campaign
): Promise<{ hook: string; body: string; hashtags: string[] }> => {
  if (!process.env.API_KEY) throw new Error("Clé API manquante");

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const systemInstruction = `
    Tu es un éditeur de contenu LinkedIn expert.
    Ta mission : modifier un post existant selon l'instruction de l'utilisateur.
    
    CONTEXTE :
    - Secteur : ${campaignContext.sector}
    - Ton : ${campaignContext.tone}

    POST ACTUEL :
    Hook: ${currentPost.hook}
    Body: ${currentPost.body}
    
    INSTRUCTION UTILISATEUR : "${instruction}"
    
    FORMAT DE SORTIE (JSON UNIQUEMENT) :
    {
      "hook": "Nouvelle accroche (si demandée, sinon garder l'ancienne)",
      "body": "Nouveau corps du texte",
      "hashtags": ["#nouveauTag"]
    }
  `;

  try {
    const result = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Applique la modification.",
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json"
      }
    });

    const text = result.text?.trim() || "";
    const cleanJson = text.replace(/```json/g, '').replace(/```/g, '');
    return JSON.parse(cleanJson);
  } catch (error) {
    console.error("Refine Post Error:", error);
    throw new Error("Impossible de modifier le post.");
  }
};

// Fonction de Streaming pour le corps du texte
export const streamPostContent = async (
  currentPost: SocialMediaPost,
  instruction: string,
  campaignContext: Campaign,
  onChunk: (text: string) => void
): Promise<void> => {
  if (!process.env.API_KEY) throw new Error("Clé API manquante");

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const systemInstruction = `
    Tu es un rédacteur LinkedIn expert.
    Ta mission : Réécrire ou générer le corps (body) du post selon l'instruction.
    N'écris QUE le corps du post. Pas d'intro, pas de "Voici le post". Juste le contenu.
    
    CONTEXTE :
    - Secteur : ${campaignContext.sector}
    - Ton : ${campaignContext.tone}
    - Post Actuel (si pertinent) : ${currentPost.body}
    
    INSTRUCTION : ${instruction}
  `;

  try {
    const response = await ai.models.generateContentStream({
      model: 'gemini-3-flash-preview',
      contents: "Génère le contenu.",
      config: {
        systemInstruction: systemInstruction,
      }
    });

    for await (const chunk of response) {
      if (chunk.text) {
        onChunk(chunk.text);
      }
    }
  } catch (error) {
    console.error("Stream Error:", error);
    throw error;
  }
};

// --- AGENT DATA ANALYST : GÉNÉRATION DE DONNÉES (Recherche + Simulation Intelligente) ---
export const generateAnalyticsData = async (
  campaign: Campaign
): Promise<{ stats: any; audience: any[]; competitors: any[] }> => {
  if (!process.env.API_KEY) throw new Error("Clé API manquante");

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const systemInstruction = `
    Tu es le Moteur d'Extraction de Données LinkedIn de LinkBoost.
    Tu DOIS utiliser Google Search pour trouver les vraies informations publiques du profil (Nom exact, Titre, Nombre d'abonnés).
    
    CONTEXTE :
    - Profil Cible : ${campaign.linkedinUrl}
    - Secteur : ${campaign.sector}

    IMPORTANT POUR LES CHIFFRES (REALITY CHECK) :
    Les vues exactes sont privées. Tu dois les ESTIMER de manière conservatrice en fonction du nombre d'abonnés trouvé via la recherche.
    - Si < 500 abonnés : Vues entre 50 et 300. Engagement faible.
    - Si 500-2000 abonnés : Vues entre 200 et 1000.
    - Si > 10000 abonnés : Vues > 5000.
    
    Ne mets JAMAIS "12k vues" si le profil a peu d'abonnés. Sois réaliste et sévère.
    
    TACHE :
    1. Cherche le profil sur Google.
    2. Extrais les concurrents réels ou les influenceurs du même secteur.
    3. Génère le JSON.

    FORMAT JSON STRICT :
    {
      "stats": {
        "totalViews": number (ESTIMATION REALISTE SUR 30 JOURS),
        "engagementRate": number (ex: 1.2),
        "targetMatchScore": number (ex: 60),
        "shares": number,
        "comments": number
      },
      "audience": [
        { "label": "Directeur Marketing", "percentage": 30, "category": "Job" },
        ...
      ],
      "competitors": [
        { 
          "id": "1", 
          "name": "Vrai Concurrent trouvé ou Leader secteur", 
          "followers": 15000, 
          "growthRate": 12, 
          "headline": "Expert...", 
          "topTopics": ["Tech", "Sales"],
          "lastPostPerformance": "High"
        }
      ]
    }
  `;

  try {
    // Utilisation de Google Search pour "grounder" les données
    const result = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Cherche ce profil LinkedIn : ${campaign.linkedinUrl}. Trouve son nombre d'abonnés, son titre et son entreprise. Ensuite, estime ses vues mensuelles de façon réaliste (taux d'impression moyen de 20% par post). Trouve aussi 2-3 concurrents réels dans le secteur ${campaign.sector}.`,
      config: {
        systemInstruction: systemInstruction,
        tools: [{ googleSearch: {} }], // ACTIVATION DE LA RECHERCHE WEB
        responseMimeType: "application/json"
      }
    });

    const text = result.text?.trim() || "";
    // Nettoyage au cas où le modèle renvoie du markdown
    const cleanJson = text.replace(/```json/g, '').replace(/```/g, '');
    
    try {
        return JSON.parse(cleanJson);
    } catch (e) {
        // Fallback si le JSON est mal formé malgré tout
        console.warn("Parsing JSON échoué, retour de données par défaut", e);
        return {
            stats: { totalViews: 0, engagementRate: 0, targetMatchScore: 0, shares: 0, comments: 0 },
            audience: [],
            competitors: []
        };
    }
  } catch (error) {
    console.error("Data Gen Error:", error);
    throw new Error("Impossible de récupérer les données LinkedIn.");
  }
};


// --- AGENT DATA ANALYST : ANALYSE STRATÉGIQUE (Insight Textuel) ---
export const analyzeDataWithAI = async (
  stats: any, 
  competitors: any, 
  targetAudience: string
): Promise<string> => {
  if (!process.env.API_KEY) throw new Error("Clé API manquante");

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const systemInstruction = `
    Tu es l'Agent Data Analyst de LinkBoost AI.
    Ton rôle : Analyser les statistiques ESTIMÉES et fournir des insights stratégiques précis.
    
    OBJECTIF CIBLE : ${targetAudience}
    
    TES MISSIONS :
    1. Analyser le "Audience Match Score".
    2. Comparer avec les concurrents trouvés.
    3. Identifier le format gagnant.
    
    RÉPONSE ATTENDUE :
    Un rapport court en texte brut (Markdown ok) avec :
    - ✅ Ce qui fonctionne (Points forts)
    - ⚠️ Ce qui cloche (Mauvaise cible, engagement faible...)
    - 🚀 3 Actions concrètes à faire maintenant.
  `;

  const prompt = `
    Voici les données (Estimations basées sur la présence publique) :
    
    PERFORMANCES ESTIMÉES :
    ${JSON.stringify(stats, null, 2)}
    
    CONCURRENTS DU SECTEUR :
    ${JSON.stringify(competitors, null, 2)}
    
    Analyse cette situation.
  `;

  try {
    const result = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
      }
    });

    return result.text || "Analyse indisponible.";
  } catch (error) {
    console.error("Data Analysis Error:", error);
    return "Impossible d'analyser les données pour le moment.";
  }
};
