
import React from 'react';
import { Link } from 'react-router-dom';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="min-h-screen bg-white p-8 md:p-16 text-slate-900 font-sans">
      <div className="max-w-3xl mx-auto">
        <Link to="/" className="inline-flex items-center gap-2 text-slate-500 hover:text-blue-600 mb-8 font-medium transition-colors">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
            Retour à l'accueil
        </Link>
        <h1 className="text-4xl font-black mb-2 text-slate-900">Politique de Confidentialité</h1>
        <p className="text-slate-500 text-lg mb-10">Dernière mise à jour : {new Date().toLocaleDateString()}</p>
        
        <div className="prose prose-slate max-w-none space-y-8">
            <section className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                <h2 className="text-xl font-bold mb-3 text-slate-800">1. Collecte des données via LinkedIn</h2>
                <p className="text-slate-600 leading-relaxed">
                    Notre application <strong>LinkBoost AI</strong> utilise l'API LinkedIn pour fournir ses services. Lorsque vous choisissez de connecter votre compte, nous demandons l'accès aux informations suivantes (scopes) :
                </p>
                <ul className="list-disc pl-5 mt-3 space-y-1 text-slate-600">
                    <li><strong>r_liteprofile</strong> : Pour afficher votre nom et votre photo de profil dans l'interface.</li>
                    <li><strong>r_emailaddress</strong> : Pour vous identifier de manière unique dans notre système.</li>
                    <li><strong>w_member_social</strong> : Uniquement pour publier les posts que vous avez explicitement validés.</li>
                </ul>
            </section>

            <section>
                <h2 className="text-xl font-bold mb-3 text-slate-800">2. Utilisation des informations</h2>
                <p className="text-slate-600 leading-relaxed">Les données collectées sont utilisées exclusivement pour :</p>
                <ul className="list-disc pl-5 mt-3 space-y-1 text-slate-600">
                    <li>Générer des analyses de performance de vos contenus.</li>
                    <li>Créer des stratégies marketing personnalisées via nos algorithmes d'IA.</li>
                    <li>Planifier et publier vos posts sur LinkedIn.</li>
                </ul>
                <p className="mt-4 text-slate-600">Nous ne vendons, n'échangeons, ni ne transférons vos informations personnelles identifiables à des tiers.</p>
            </section>

            <section>
                <h2 className="text-xl font-bold mb-3 text-slate-800">3. Sécurité des données</h2>
                <p className="text-slate-600 leading-relaxed">
                    Nous mettons en œuvre des mesures de sécurité strictes. Les jetons d'accès (Tokens OAuth) sont stockés de manière sécurisée et ne sont jamais exposés côté client (navigateur) de manière permanente.
                </p>
            </section>

            <section>
                <h2 className="text-xl font-bold mb-3 text-slate-800">4. Vos droits</h2>
                <p className="text-slate-600 leading-relaxed">
                    Vous pouvez à tout moment révoquer l'accès de LinkBoost AI à votre compte LinkedIn via vos <a href="https://www.linkedin.com/psettings/permitted-services" target="_blank" className="text-blue-600 underline hover:text-blue-800">paramètres LinkedIn</a>. Vous pouvez également demander la suppression de toutes vos données de nos serveurs en nous contactant.
                </p>
            </section>
            
            <div className="pt-8 border-t border-slate-200">
                <p className="text-xs text-slate-400">LinkBoost AI est une application indépendante et n'est pas affiliée à LinkedIn Corporation.</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
