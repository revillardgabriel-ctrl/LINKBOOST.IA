
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Campaign, AudienceDemographic, Competitor } from '../types';
import { analyzeDataWithAI, generateAnalyticsData } from '../services/geminiService';

interface AnalyticsProps {
  campaigns: Campaign[];
}

type TabView = 'overview' | 'audience' | 'content' | 'competitors';

const Analytics: React.FC<AnalyticsProps> = ({ campaigns }) => {
  const { tab } = useParams<{ tab?: string }>();
  const navigate = useNavigate();
  
  // On sélectionne par défaut la dernière campagne créée ou la première de la liste
  const [selectedCampaignId, setSelectedCampaignId] = useState(campaigns.length > 0 ? campaigns[0].id : '');
  
  // On récupère l'objet campagne complet basé sur l'ID sélectionné
  const campaign = campaigns.find(c => c.id === selectedCampaignId);
  
  const [activeTab, setActiveTab] = useState<TabView>('overview');
  const [loadingAnalysis, setLoadingAnalysis] = useState(false);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [dataLoaded, setDataLoaded] = useState(false);

  // --- ÉTATS DES DONNÉES (Initialisés vides) ---
  const [audienceData, setAudienceData] = useState<AudienceDemographic[]>([]);
  const [competitors, setCompetitors] = useState<Competitor[]>([]);
  const [stats, setStats] = useState<any>({
      totalViews: 0,
      engagementRate: 0,
      targetMatchScore: 0,
      shares: 0,
      comments: 0
  });

  // Synchronisation avec l'URL pour les onglets
  useEffect(() => {
    if (tab && ['overview', 'audience', 'content', 'competitors'].includes(tab)) {
      setActiveTab(tab as TabView);
    } else {
      setActiveTab('overview');
    }
  }, [tab]);

  // Réinitialiser l'état quand on change de campagne dans le menu déroulant
  useEffect(() => {
    setDataLoaded(false);
    setAiInsight(null);
    setStats({ totalViews: 0, engagementRate: 0, targetMatchScore: 0, shares: 0, comments: 0 });
    setAudienceData([]);
    setCompetitors([]);
  }, [selectedCampaignId]);

  const handleTabChange = (newTab: TabView) => {
    setActiveTab(newTab);
    navigate(`/analytics/${newTab}`);
  };

  // Helper pour extraire un nom lisible de l'URL LinkedIn
  const getProfileName = (url: string) => {
    try {
        const parts = url.split('/in/');
        if (parts.length > 1) {
            return parts[1].replace(/\/$/, '');
        }
        return url;
    } catch (e) {
        return "Profil Inconnu";
    }
  };

  // --- ACTIONS ---

  const handleRunAnalysis = async () => {
    if (!campaign) return;
    setLoadingAnalysis(true);
    setAiInsight(null);
    
    try {
        // 1. Simulation d'attente "Connexion au profil LinkedIn..."
        await new Promise(r => setTimeout(r, 1500));

        // 2. Génération des données brutes par l'IA (Simulation Scraping) basé sur la campagne SÉLECTIONNÉE
        const generatedData = await generateAnalyticsData(campaign);
        
        setStats(generatedData.stats);
        setAudienceData(generatedData.audience);
        setCompetitors(generatedData.competitors);
        setDataLoaded(true);

        // 3. Analyse stratégique des données générées
        const insight = await analyzeDataWithAI(
            generatedData.stats, 
            generatedData.competitors, 
            campaign.targetAudience || "Professionnels B2B"
        );
        setAiInsight(insight);

    } catch (e) {
        console.error(e);
        setAiInsight("Erreur : Impossible de récupérer les données du profil. Vérifiez l'URL ou réessayez.");
    } finally {
        setLoadingAnalysis(false);
    }
  };

  if (!campaign) return <div className="p-20 text-center text-slate-400 font-bold">Veuillez d'abord créer une campagne pour activer l'Agent Data.</div>;

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 pb-20">
      
      {/* --- HEADER AGENT --- */}
      <header className="bg-white border-b border-slate-200 pt-12 pb-8 px-8 md:px-12 shadow-sm relative overflow-hidden">
        {/* Background decorations */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-purple-50 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>

        <div className="max-w-7xl mx-auto relative z-10">
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-8">
                <div>
                    <div className="flex items-center gap-3 mb-2">
                        <span className={`w-3 h-3 rounded-full shadow-[0_0_10px_rgba(168,85,247,0.5)] transition-colors duration-500 ${dataLoaded ? 'bg-green-500 animate-pulse' : 'bg-amber-400'}`}></span>
                        <span className="text-xs font-bold uppercase tracking-widest text-slate-400">
                            {dataLoaded ? "Flux de données Actif" : "En attente d'analyse"}
                        </span>
                    </div>
                    <h1 className="text-5xl md:text-7xl font-black text-slate-900 tracking-tighter leading-none mb-4">
                        AGENT <span className="text-purple-600">DATA</span>
                    </h1>
                    <p className="text-xl text-slate-500 font-medium max-w-2xl leading-relaxed">
                        J'analyse les métriques de <span className="text-slate-900 font-bold underline decoration-purple-300 decoration-4 underline-offset-4">{getProfileName(campaign.linkedinUrl)}</span> pour optimiser votre croissance.
                    </p>
                </div>
                
                {/* --- SÉLECTEUR DE CAMPAGNE & ACTION (LE CŒUR DE LA DEMANDE) --- */}
                <div className="flex flex-col w-full lg:w-auto bg-slate-50 p-2 rounded-2xl border border-slate-200 shadow-sm">
                    <label className="text-[10px] font-bold uppercase text-slate-400 px-2 pt-1 mb-1">Sélectionner un profil à analyser</label>
                    <div className="flex flex-col sm:flex-row gap-2">
                        {/* Dropdown Intelligent */}
                        <div className="relative flex-1 sm:w-72">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <svg className="h-5 w-5 text-blue-600" fill="currentColor" viewBox="0 0 24 24"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z"/></svg>
                            </div>
                            <select 
                                value={selectedCampaignId} 
                                onChange={(e) => setSelectedCampaignId(e.target.value)}
                                className="block w-full pl-10 pr-10 py-3 text-base border-none focus:outline-none focus:ring-0 bg-white rounded-xl font-bold text-slate-800 shadow-sm cursor-pointer hover:bg-slate-100 transition-colors appearance-none"
                            >
                                {campaigns.map(c => (
                                    <option key={c.id} value={c.id}>
                                        {getProfileName(c.linkedinUrl)} — {c.goal}
                                    </option>
                                ))}
                            </select>
                            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                <svg className="h-4 w-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"/></svg>
                            </div>
                        </div>

                        {/* Bouton d'Action */}
                        <button 
                            onClick={handleRunAnalysis}
                            disabled={loadingAnalysis}
                            className={`
                                px-6 py-3 rounded-xl text-sm font-black uppercase tracking-widest shadow-lg flex items-center justify-center gap-2 transition-all whitespace-nowrap
                                ${loadingAnalysis 
                                    ? 'bg-slate-100 text-slate-400 cursor-wait' 
                                    : 'bg-purple-600 text-white hover:bg-purple-700 hover:scale-105 shadow-purple-500/30'
                                }
                            `}
                        >
                            {loadingAnalysis ? <span className="animate-spin">⚙️</span> : <span>📡</span>}
                            {loadingAnalysis ? 'Analyse en cours...' : 'Lancer l\'analyse'}
                        </button>
                    </div>
                </div>
            </div>

            {/* AI Insight Box */}
            {aiInsight && (
                <div className="mt-10 animate-in slide-in-from-top-4 fade-in duration-500">
                    <div className="bg-gradient-to-br from-purple-600 to-indigo-700 rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-8 opacity-10">
                            <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                        </div>
                        <h3 className="text-lg font-black uppercase tracking-widest mb-4 flex items-center gap-2 border-b border-white/20 pb-4">
                            <span>⚡️</span> Rapport Stratégique pour {getProfileName(campaign.linkedinUrl)}
                        </h3>
                        <div className="prose prose-invert max-w-none">
                            <pre className="whitespace-pre-wrap font-sans text-sm md:text-base leading-relaxed text-purple-50">
                                {aiInsight}
                            </pre>
                        </div>
                    </div>
                </div>
            )}
        </div>
      </header>

      {/* --- NAVIGATION --- */}
      <div className="max-w-7xl mx-auto px-8 md:px-12 mt-8">
        <div className="flex overflow-x-auto pb-4 gap-2 no-scrollbar border-b border-slate-200">
            {[
                { id: 'overview', label: 'Vue d\'ensemble', icon: '📊' },
                { id: 'content', label: 'Analyse des Posts', icon: '📝' },
                { id: 'competitors', label: 'Veille Concurrentielle', icon: '🕵️' },
                { id: 'audience', label: 'Qualité Audience', icon: '👥' }
            ].map(tab => (
                <button
                    key={tab.id}
                    onClick={() => handleTabChange(tab.id as TabView)}
                    disabled={!dataLoaded}
                    className={`
                        px-6 py-3 rounded-t-xl font-bold text-sm flex items-center gap-2 transition-all border-b-2
                        ${activeTab === tab.id 
                            ? 'border-purple-600 text-purple-600 bg-purple-50/50' 
                            : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-100'
                        }
                        ${!dataLoaded ? 'opacity-50 cursor-not-allowed' : ''}
                    `}
                >
                    <span>{tab.icon}</span>
                    {tab.label}
                </button>
            ))}
        </div>
      </div>

      {/* --- CONTENU DES ONGLETS --- */}
      <main className="max-w-7xl mx-auto px-8 md:px-12 py-8 min-h-[500px]">
        
        {!dataLoaded ? (
            <div className="flex flex-col items-center justify-center h-96 text-center animate-in fade-in zoom-in duration-500">
                <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mb-6 shadow-inner">
                    <span className="text-4xl">📡</span>
                </div>
                <h3 className="text-2xl font-black text-slate-900 mb-2">Prêt à scanner</h3>
                <p className="text-slate-500 max-w-md">
                    Vous avez sélectionné <strong>{getProfileName(campaign.linkedinUrl)}</strong>. <br/>
                    Cliquez sur "Lancer l'analyse" ci-dessus pour récupérer les données en temps réel.
                </p>
            </div>
        ) : (
            <>
                {/* VUE D'ENSEMBLE */}
                {activeTab === 'overview' && (
                    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 space-y-8">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            {/* KPI Cards */}
                            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
                                <div className="flex justify-between items-start mb-4">
                                    <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Vues (30j)</span>
                                    <span className="text-xs font-bold text-green-600 bg-green-50 px-2 py-1 rounded">+12%</span>
                                </div>
                                <div className="text-4xl font-black text-slate-900 group-hover:text-purple-600 transition-colors">
                                    {stats.totalViews.toLocaleString()}
                                </div>
                            </div>
                            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
                                <div className="flex justify-between items-start mb-4">
                                    <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Engagement</span>
                                    <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded">Moyen</span>
                                </div>
                                <div className="text-4xl font-black text-slate-900 group-hover:text-purple-600 transition-colors">
                                    {stats.engagementRate}%
                                </div>
                            </div>
                            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
                                <div className="flex justify-between items-start mb-4">
                                    <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Target Match</span>
                                    <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded">Score</span>
                                </div>
                                <div className="text-4xl font-black text-slate-900 group-hover:text-blue-600 transition-colors">
                                    {stats.targetMatchScore}/100
                                </div>
                                <div className="w-full h-1.5 bg-slate-100 rounded-full mt-3 overflow-hidden">
                                    <div className="h-full bg-blue-600" style={{ width: `${stats.targetMatchScore}%` }}></div>
                                </div>
                            </div>
                            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
                                <div className="flex justify-between items-start mb-4">
                                    <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Partages</span>
                                </div>
                                <div className="text-4xl font-black text-slate-900 group-hover:text-amber-500 transition-colors">
                                    {stats.shares}
                                </div>
                            </div>
                        </div>

                        {/* Graphique Simplifié */}
                        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                            <h3 className="font-bold text-lg text-slate-900 mb-6">Croissance de l'audience (Simulée)</h3>
                            <div className="h-64 flex items-end justify-between gap-2 px-4">
                                {[40, 65, 45, 70, 55, 80, 75, 90, 85, 95, 100, 110].map((h, i) => (
                                    <div key={i} className="w-full bg-slate-100 rounded-t-lg relative group transition-all hover:bg-purple-50">
                                        <div 
                                            className="absolute bottom-0 w-full bg-slate-800 rounded-t-lg transition-all group-hover:bg-purple-600" 
                                            style={{ height: `${(h/120)*100}%` }}
                                        ></div>
                                    </div>
                                ))}
                            </div>
                            <div className="flex justify-between mt-4 text-xs font-bold text-slate-400 uppercase tracking-widest">
                                <span>Semaine 1</span>
                                <span>Semaine 4</span>
                            </div>
                        </div>
                    </div>
                )}

                {/* AUDIENCE */}
                {activeTab === 'audience' && (
                    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 grid md:grid-cols-2 gap-8">
                        <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
                            <h3 className="text-lg font-black text-slate-900 mb-6 flex items-center gap-2">
                                <span>🎯</span> Par Métier
                            </h3>
                            <div className="space-y-5">
                                {audienceData.filter(d => d.category === 'Job').map((d, i) => (
                                    <div key={i}>
                                        <div className="flex justify-between text-sm font-bold text-slate-700 mb-1">
                                            <span>{d.label}</span>
                                            <span>{d.percentage}%</span>
                                        </div>
                                        <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                                            <div className="bg-slate-900 h-full rounded-full" style={{ width: `${d.percentage}%` }}></div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
                            <h3 className="text-lg font-black text-slate-900 mb-6 flex items-center gap-2">
                                <span>🏭</span> Par Secteur
                            </h3>
                            <div className="space-y-5">
                                {audienceData.filter(d => d.category === 'Industry').map((d, i) => (
                                    <div key={i}>
                                        <div className="flex justify-between text-sm font-bold text-slate-700 mb-1">
                                            <span>{d.label}</span>
                                            <span>{d.percentage}%</span>
                                        </div>
                                        <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                                            <div className="bg-purple-600 h-full rounded-full" style={{ width: `${d.percentage}%` }}></div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="md:col-span-2 bg-gradient-to-r from-slate-900 to-slate-800 rounded-3xl p-8 text-white flex items-center justify-between">
                            <div>
                                <h4 className="font-bold text-xl mb-2">Alignement Cible</h4>
                                <p className="text-slate-300 max-w-lg">
                                    Score calculé sur l'adéquation entre votre audience actuelle et votre cible idéale "{campaign.targetAudience}".
                                </p>
                            </div>
                            <div className="text-4xl font-black text-green-400">{stats.targetMatchScore}/100</div>
                        </div>
                    </div>
                )}

                {/* CONTENU */}
                {activeTab === 'content' && (
                     <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
                        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
                            <table className="w-full text-left">
                                <thead className="bg-slate-50 border-b border-slate-200">
                                    <tr>
                                        <th className="py-5 px-6 text-xs font-black uppercase text-slate-400 tracking-widest">Post</th>
                                        <th className="py-5 px-6 text-xs font-black uppercase text-slate-400 tracking-widest text-right">Type</th>
                                        <th className="py-5 px-6 text-xs font-black uppercase text-slate-400 tracking-widest text-right">Vues</th>
                                        <th className="py-5 px-6 text-xs font-black uppercase text-slate-400 tracking-widest text-right">Interactions</th>
                                        <th className="py-5 px-6 text-xs font-black uppercase text-slate-400 tracking-widest text-center">Score IA</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                    {campaign.result?.posts.map((post, i) => (
                                        <tr key={i} className="hover:bg-purple-50/30 transition-colors group cursor-pointer">
                                            <td className="py-4 px-6">
                                                <div className="font-bold text-slate-900 truncate max-w-md group-hover:text-purple-600 transition-colors">
                                                    "{post.hook}"
                                                </div>
                                                <div className="text-xs text-slate-500 mt-1">Publié le {new Date().toLocaleDateString()}</div>
                                            </td>
                                            <td className="py-4 px-6 text-right">
                                                <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded text-xs font-bold uppercase">{post.type}</span>
                                            </td>
                                            <td className="py-4 px-6 text-right font-medium text-slate-700">
                                                {(Math.random() * 5000 + 500).toFixed(0)}
                                            </td>
                                            <td className="py-4 px-6 text-right font-medium text-slate-700">
                                                {(Math.random() * 200 + 20).toFixed(0)}
                                            </td>
                                            <td className="py-4 px-6 text-center">
                                                <span className="w-8 h-8 rounded-full bg-green-100 text-green-700 flex items-center justify-center font-bold text-xs mx-auto">A+</span>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                     </div>
                )}

                {/* CONCURRENCE */}
                {activeTab === 'competitors' && (
                    <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
                         <div className="grid md:grid-cols-3 gap-6 mb-8">
                            {competitors.map(comp => (
                                <div key={comp.id} className="bg-white rounded-3xl border border-slate-200 p-6 hover:shadow-xl hover:scale-[1.02] transition-all group cursor-pointer relative overflow-hidden">
                                    {comp.growthRate > 10 && (
                                        <div className="absolute top-0 right-0 bg-red-500 text-white text-[10px] font-black uppercase px-2 py-1 rounded-bl-lg">Danger</div>
                                    )}
                                    <div className="flex items-center gap-4 mb-4">
                                        <div className="w-12 h-12 rounded-full bg-slate-200 flex items-center justify-center font-bold text-xl text-slate-500">
                                            {comp.name.charAt(0)}
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-slate-900">{comp.name}</h4>
                                            <p className="text-xs text-slate-500">{comp.followers.toLocaleString()} abonnés</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2 mb-4">
                                        <span className={`text-xs font-bold px-2 py-1 rounded ${comp.growthRate > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                            {comp.growthRate > 0 ? '+' : ''}{comp.growthRate}% Growth
                                        </span>
                                        <span className="text-xs font-medium text-slate-400">cette semaine</span>
                                    </div>
                                    <div>
                                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Sujets chauds</p>
                                        <div className="flex flex-wrap gap-2">
                                            {comp.topTopics.map(topic => (
                                                <span key={topic} className="px-2 py-1 bg-slate-50 border border-slate-100 rounded-md text-xs font-medium text-slate-600 group-hover:bg-purple-50 group-hover:text-purple-600 transition-colors">
                                                    #{topic}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            ))}
                            
                            {/* Add Competitor Card */}
                            <button className="rounded-3xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-slate-400 hover:border-purple-400 hover:text-purple-600 hover:bg-purple-50 transition-all min-h-[200px]">
                                <span className="text-4xl mb-2">+</span>
                                <span className="text-sm font-bold uppercase tracking-widest">Ajouter une cible</span>
                            </button>
                         </div>
                    </div>
                )}
            </>
        )}

      </main>
    </div>
  );
};

export default Analytics;
