
import React, { useState, useEffect, useRef } from 'react';
import { Campaign, SocialMediaPost } from '../types';

interface PlanningProps {
  campaigns: Campaign[];
  onUpdate: (c: Campaign) => void;
}

const Planning: React.FC<PlanningProps> = ({ campaigns, onUpdate }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedSlot, setSelectedSlot] = useState<{date: Date, hour: number} | null>(null);
  const [selectedPost, setSelectedPost] = useState<SocialMediaPost | null>(null);
  
  // NOUVEAU : Mode Placement Rapide
  const [placementMode, setPlacementMode] = useState<SocialMediaPost | null>(null);
  const [isBacklogOpen, setIsBacklogOpen] = useState(true);
  
  // Indicateur "Maintenant"
  const [nowPosition, setNowPosition] = useState(0);

  // Gestion Upload Média
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [tempMedia, setTempMedia] = useState<{url: string, type: 'image'|'video'} | null>(null);

  useEffect(() => {
    const updatePosition = () => {
      const now = new Date();
      setNowPosition(now.getMinutes());
    };
    updatePosition();
    const interval = setInterval(updatePosition, 60000);
    return () => clearInterval(interval);
  }, []);

  // Reset temp media quand on ferme la modale de création
  useEffect(() => {
    if (!selectedSlot) setTempMedia(null);
  }, [selectedSlot]);

  // --- LOGIQUE CALENDRIER ---

  const getDaysOfWeek = (date: Date) => {
    const start = new Date(date);
    const day = start.getDay(); // 0 dim, 1 lun
    const diff = start.getDate() - day + (day === 0 ? -6 : 1); // ajuster pour lundi
    start.setDate(diff);
    const days = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      days.push(d);
    }
    return days;
  };

  const weekDays = getDaysOfWeek(currentDate);
  const startHour = 7;
  const endHour = 20;
  const hours = Array.from({ length: endHour - startHour + 1 }, (_, i) => i + startHour);

  const allPosts = campaigns.flatMap(c => 
    (c.result?.posts || []).map(p => ({ ...p, campaignId: c.id }))
  );

  const getPostForSlot = (day: Date, hour: number) => {
    return allPosts.find(p => {
      if (!p.scheduledDate) return false;
      const pDate = new Date(p.scheduledDate);
      return (
        pDate.getDate() === day.getDate() &&
        pDate.getMonth() === day.getMonth() &&
        pDate.getFullYear() === day.getFullYear() &&
        pDate.getHours() === hour
      );
    });
  };

  const isToday = (date: Date) => {
    const today = new Date();
    return date.getDate() === today.getDate() &&
           date.getMonth() === today.getMonth() &&
           date.getFullYear() === today.getFullYear();
  };

  // --- ACTIONS ---

  const handleNextWeek = () => { const d = new Date(currentDate); d.setDate(d.getDate() + 7); setCurrentDate(d); };
  const handlePrevWeek = () => { const d = new Date(currentDate); d.setDate(d.getDate() - 7); setCurrentDate(d); };
  
  const handleSlotClick = (date: Date, hour: number) => {
    const existingPost = getPostForSlot(date, hour);
    if (existingPost) {
        setSelectedPost(existingPost);
        setPlacementMode(null);
        return;
    }

    if (placementMode) {
        handleScheduleDraft(placementMode, date, hour);
        setPlacementMode(null);
        return;
    }

    setSelectedSlot({ date, hour });
  };

  const handleScheduleDraft = (post: SocialMediaPost, date: Date, hour: number) => {
    const scheduleDate = new Date(date);
    scheduleDate.setHours(hour, 0, 0, 0);
    
    const campaign = campaigns.find(c => c.id === (post as any).campaignId);
    if (campaign && campaign.result) {
        const updatedPosts = campaign.result.posts.map(p => 
            p.id === post.id 
            ? { ...p, status: 'scheduled' as const, scheduledDate: scheduleDate.toISOString() } 
            : p
        );
        onUpdate({ ...campaign, result: { ...campaign.result, posts: updatedPosts } });
    }
  };

  const handleUnschedule = (post: SocialMediaPost) => {
     const campaign = campaigns.find(c => c.id === (post as any).campaignId);
     if (campaign && campaign.result) {
        const updatedPosts = campaign.result.posts.map(p => 
            p.id === post.id 
            ? { ...p, status: 'draft' as const, scheduledDate: undefined } 
            : p
        );
        onUpdate({ ...campaign, result: { ...campaign.result, posts: updatedPosts } });
    }
    setSelectedPost(null);
  };

  // --- GESTION FICHIERS ---
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
            setTempMedia({
                url: reader.result as string,
                type: file.type.startsWith('video') ? 'video' : 'image'
            });
        };
        reader.readAsDataURL(file);
    }
  };

  const handleCreateQuickPost = () => {
    if (!selectedSlot) return;
    const campaign = campaigns[0];
    if (!campaign || !campaign.result) return;

    const scheduleDate = new Date(selectedSlot.date);
    scheduleDate.setHours(selectedSlot.hour, 0, 0, 0);

    const newPost: SocialMediaPost = {
       id: `quick_${Date.now()}`,
       plateforme: 'LinkedIn',
       status: 'scheduled',
       scheduledDate: scheduleDate.toISOString(),
       type: 'Quick Post',
       hook: 'Nouveau post',
       body: 'Contenu à rédiger...',
       hashtags: [],
       conseil_visuel: '',
       mediaUrl: tempMedia?.url,
       mediaType: tempMedia?.type
    };

    onUpdate({ ...campaign, result: { ...campaign.result, posts: [newPost, ...campaign.result.posts] } });
    setSelectedSlot(null);
    setSelectedPost(newPost);
  };

  const getCategoryColor = (type?: string) => {
      const t = (type || '').toLowerCase();
      if (t.includes('story')) return 'bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100';
      if (t.includes('autorit')) return 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100';
      if (t.includes('vente') || t.includes('offr')) return 'bg-green-50 text-green-700 border-green-200 hover:bg-green-100';
      return 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100';
  };

  return (
    <div className="flex h-[calc(100vh-64px)] bg-white overflow-hidden font-sans">
      
      {/* === ZONE CALENDRIER === */}
      <div className="flex-1 flex flex-col min-w-0 bg-white">
        
        {/* Toolbar */}
        <header className="px-6 py-3 border-b border-slate-200 flex justify-between items-center bg-white z-20 shadow-[0_1px_3px_rgba(0,0,0,0.02)]">
           <div className="flex items-center gap-6">
              <h1 className="text-xl font-bold text-slate-800 tracking-tight">Calendrier</h1>
              <div className="flex items-center bg-slate-50 rounded-lg p-1 border border-slate-200">
                  <button onClick={handlePrevWeek} className="p-1.5 hover:bg-white hover:shadow-sm rounded-md text-slate-500 transition-all"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"/></svg></button>
                  <button onClick={() => setCurrentDate(new Date())} className="px-4 text-xs font-bold uppercase tracking-wider text-slate-600">Aujourd'hui</button>
                  <button onClick={handleNextWeek} className="p-1.5 hover:bg-white hover:shadow-sm rounded-md text-slate-500 transition-all"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"/></svg></button>
              </div>
              <span className="text-sm font-semibold text-slate-600 uppercase tracking-wide">
                 {weekDays[0].toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}
              </span>
           </div>
           
           <button 
                onClick={() => setIsBacklogOpen(!isBacklogOpen)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${isBacklogOpen ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:bg-slate-50'}`}
           >
                <span>{isBacklogOpen ? 'Masquer Backlog' : 'Afficher Backlog'}</span>
                <span className="bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded text-[10px] font-bold">
                    {allPosts.filter(p => p.status === 'draft').length}
                </span>
           </button>
        </header>

        {/* Grille Principale */}
        <div className="flex-1 overflow-y-auto relative custom-scrollbar bg-white">
           
           {/* HEADER STICKY */}
           <div className="sticky top-0 z-30 flex border-b border-slate-200 bg-slate-50 shadow-sm">
              <div className="w-20 flex-shrink-0 bg-white border-r border-slate-200"></div>
              <div className="flex-1 grid grid-cols-7">
                {weekDays.map((day, i) => {
                    const today = isToday(day);
                    return (
                        <div key={i} className={`py-3 text-center border-r border-slate-200 last:border-r-0 ${today ? 'bg-blue-50/50' : ''}`}>
                            <span className={`block text-[10px] font-bold uppercase mb-1 ${today ? 'text-blue-600' : 'text-slate-400'}`}>
                                {day.toLocaleDateString('fr-FR', { weekday: 'short' })}
                            </span>
                            <div className={`w-8 h-8 mx-auto flex items-center justify-center rounded-full text-sm font-bold ${today ? 'bg-blue-600 text-white' : 'text-slate-700'}`}>
                                {day.getDate()}
                            </div>
                        </div>
                    );
                })}
              </div>
           </div>

           {/* CORPS DE LA GRILLE */}
           <div className="relative">
              {/* LIGNE "MAINTENANT" */}
              {(() => {
                  const now = new Date();
                  const currentHour = now.getHours();
                  if (currentHour >= startHour && currentHour <= endHour) {
                      const topPx = (currentHour - startHour) * 96 + (now.getMinutes() / 60) * 96;
                      return (
                          <div className="absolute left-0 right-0 z-20 flex items-center pointer-events-none" style={{ top: `${topPx}px` }}>
                              <div className="w-20 pr-2 text-right text-[10px] font-bold text-red-500 bg-white">
                                  {now.toLocaleTimeString('fr-FR', {hour: '2-digit', minute:'2-digit'})}
                              </div>
                              <div className="flex-1 h-px bg-red-500 relative">
                                  <div className="absolute -left-1 -top-1 w-2 h-2 rounded-full bg-red-500"></div>
                              </div>
                          </div>
                      );
                  }
                  return null;
              })()}

              {hours.map((hour) => (
                  <div key={hour} className="flex h-24 border-b border-slate-100">
                      <div className="w-20 flex-shrink-0 border-r border-slate-200 bg-white text-[11px] font-medium text-slate-400 text-right pr-3 pt-2 relative">
                          <span className="-top-2.5 relative">{hour}:00</span>
                      </div>

                      <div className="flex-1 grid grid-cols-7 w-full">
                          {weekDays.map((day, i) => {
                              const post = getPostForSlot(day, hour);
                              const isPast = day < new Date() && day.toDateString() !== new Date().toDateString();
                              
                              return (
                                  <div 
                                      key={i} 
                                      className={`
                                          border-r border-slate-100 last:border-r-0 relative p-1 transition-all group
                                          ${isPast ? 'bg-slate-50/40 pattern-diagonal-lines' : 'bg-white'}
                                          ${placementMode && !post && !isPast ? 'hover:bg-blue-50 cursor-copy' : ''} 
                                          ${!placementMode && !post && !isPast ? 'hover:bg-slate-50 cursor-pointer' : ''}
                                      `}
                                      onClick={() => handleSlotClick(day, hour)}
                                  >
                                      {post ? (
                                          <div className={`h-full w-full rounded-md border-l-[3px] shadow-sm p-2 cursor-pointer hover:shadow-md hover:scale-[1.02] transition-all flex flex-col justify-between overflow-hidden ${getCategoryColor(post.type)}`}>
                                              <div className="flex flex-col gap-0.5">
                                                  <span className="text-[9px] font-black uppercase opacity-60 tracking-wider truncate flex justify-between">
                                                      {post.type}
                                                      {post.mediaUrl && <span title="Média attaché">📎</span>}
                                                  </span>
                                                  <span className="text-xs font-bold leading-tight line-clamp-2 text-slate-800">{post.hook}</span>
                                              </div>
                                              <div className="mt-1 flex items-center opacity-50">
                                                  <span className="text-[9px] font-bold">{hour}:00</span>
                                              </div>
                                          </div>
                                      ) : (
                                          <>
                                            {placementMode && !isPast && (
                                                <div className="absolute inset-0 bg-blue-100/50 border-2 border-dashed border-blue-300 opacity-0 group-hover:opacity-100 flex items-center justify-center text-blue-600 text-xs font-bold pointer-events-none rounded-lg m-1">
                                                    Placer ici
                                                </div>
                                            )}
                                            {!placementMode && !isPast && (
                                                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 pointer-events-none">
                                                    <div className="w-6 h-6 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center pb-0.5 font-light text-xl">+</div>
                                                </div>
                                            )}
                                          </>
                                      )}
                                  </div>
                              );
                          })}
                      </div>
                  </div>
              ))}
           </div>
        </div>
      </div>

      {/* === SIDEBAR BACKLOG === */}
      {isBacklogOpen && (
        <aside className="w-80 bg-slate-50 border-l border-slate-200 flex flex-col shadow-[0_0_15px_rgba(0,0,0,0.05)] z-40 animate-in slide-in-from-right duration-300">
           <div className="p-4 border-b border-slate-200 bg-white">
              <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wide mb-1">Brouillons ({allPosts.filter(p => p.status === 'draft').length})</h3>
              <p className="text-xs text-slate-400">Cliquez sur un post, puis cliquez dans l'agenda.</p>
           </div>
           <div className="flex-1 overflow-y-auto p-3 space-y-3 custom-scrollbar">
              {allPosts.filter(p => p.status === 'draft').length > 0 ? (
                  allPosts.filter(p => p.status === 'draft').map(post => {
                    const isSelected = placementMode?.id === post.id;
                    return (
                        <div 
                            key={post.id} 
                            onClick={() => setPlacementMode(isSelected ? null : post)}
                            className={`
                                p-3 rounded-xl border transition-all cursor-pointer group relative
                                ${isSelected 
                                    ? 'bg-blue-600 border-blue-600 shadow-lg shadow-blue-500/30 transform scale-[1.02] z-10' 
                                    : 'bg-white border-slate-200 hover:border-blue-400 hover:shadow-md'
                                }
                            `}
                        >
                            <div className="flex justify-between items-start mb-2">
                                <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wide border ${isSelected ? 'bg-white/20 text-white border-transparent' : 'bg-slate-100 text-slate-500 border-slate-100'}`}>
                                    {post.type}
                                </span>
                                {post.mediaUrl && <span className={`text-xs ${isSelected ? 'text-white' : 'text-slate-400'}`}>📎</span>}
                            </div>
                            <p className={`text-sm font-semibold line-clamp-2 leading-snug ${isSelected ? 'text-white' : 'text-slate-800'}`}>
                                {post.hook || "Sans titre"}
                            </p>
                        </div>
                    );
                  })
              ) : (
                  <div className="flex flex-col items-center justify-center h-40 text-slate-400 text-center">
                      <p className="text-sm font-medium">Tout est planifié !</p>
                  </div>
              )}
           </div>
           <div className="p-4 border-t border-slate-200 bg-slate-100 text-center">
                <button 
                    onClick={() => { setPlacementMode(null); setSelectedSlot({date: new Date(), hour: 9}); }}
                    className="w-full py-3 bg-white border border-slate-300 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors shadow-sm"
                >
                    + Créer un brouillon
                </button>
           </div>
        </aside>
      )}

      {/* --- MODAL CREATION RAPIDE --- */}
      {selectedSlot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 animate-in fade-in duration-200">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden">
                <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center">
                    <h3 className="font-bold text-slate-800">Nouveau Post</h3>
                    <button onClick={() => setSelectedSlot(null)} className="text-slate-400 hover:text-slate-600">✕</button>
                </div>
                <div className="p-6">
                    <p className="text-sm text-slate-500 mb-6">
                        Pour le <strong>{selectedSlot.date.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric' })}</strong> à <strong>{selectedSlot.hour}h00</strong>.
                    </p>
                    
                    {/* ZONE UPLOAD */}
                    <div className="mb-6">
                        <input 
                            type="file" 
                            accept="image/*,video/*" 
                            className="hidden" 
                            ref={fileInputRef}
                            onChange={handleFileSelect}
                        />
                        <div 
                            onClick={() => fileInputRef.current?.click()}
                            className="w-full h-32 border-2 border-dashed border-slate-300 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:bg-slate-50 hover:border-blue-400 transition-all overflow-hidden relative"
                        >
                            {tempMedia ? (
                                tempMedia.type === 'video' ? (
                                    <video src={tempMedia.url} className="w-full h-full object-cover" controls />
                                ) : (
                                    <img src={tempMedia.url} alt="Preview" className="w-full h-full object-cover" />
                                )
                            ) : (
                                <>
                                    <svg className="w-8 h-8 text-slate-300 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                    <span className="text-xs font-bold text-slate-400 uppercase">Ajouter Photo/Vidéo</span>
                                </>
                            )}
                            {tempMedia && (
                                <button 
                                    onClick={(e) => { e.stopPropagation(); setTempMedia(null); }}
                                    className="absolute top-2 right-2 bg-black/50 text-white rounded-full p-1 hover:bg-red-500"
                                >
                                    ✕
                                </button>
                            )}
                        </div>
                    </div>

                    <button 
                        onClick={handleCreateQuickPost}
                        className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                    >
                        Créer et Éditer
                    </button>
                    <div className="mt-4 text-center">
                        <button onClick={() => setSelectedSlot(null)} className="text-xs font-bold text-slate-400 hover:text-slate-600 uppercase tracking-wide">Annuler</button>
                    </div>
                </div>
            </div>
        </div>
      )}

      {/* --- MODAL DETAIL POST --- */}
      {selectedPost && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4 animate-in zoom-in-95 duration-200">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
                  <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-start bg-slate-50/50">
                      <div>
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide border bg-white border-slate-200 mb-2`}>
                              {selectedPost.type}
                          </span>
                          <h3 className="text-lg font-bold text-slate-900 leading-tight line-clamp-1">{selectedPost.hook}</h3>
                      </div>
                      <button onClick={() => setSelectedPost(null)} className="text-slate-400 hover:text-slate-600 bg-white rounded-full p-1 hover:bg-slate-100 transition-colors">
                          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
                      </button>
                  </div>
                  
                  <div className="p-6 overflow-y-auto custom-scrollbar flex-1 bg-white">
                      {/* AFFICHAGE MEDIA */}
                      {selectedPost.mediaUrl && (
                          <div className="mb-4 rounded-xl overflow-hidden border border-slate-200 bg-slate-50">
                              {selectedPost.mediaType === 'video' ? (
                                  <video src={selectedPost.mediaUrl} controls className="w-full max-h-60 object-cover" />
                              ) : (
                                  <img src={selectedPost.mediaUrl} alt="Post media" className="w-full max-h-60 object-cover" />
                              )}
                          </div>
                      )}

                      <p className="text-slate-600 whitespace-pre-wrap leading-relaxed text-sm">{selectedPost.body}</p>
                      
                      {selectedPost.hashtags && selectedPost.hashtags.length > 0 && (
                          <div className="mt-4 flex flex-wrap gap-2 pt-4 border-t border-slate-50">
                              {selectedPost.hashtags.map(t => (
                                  <span key={t} className="text-blue-600 bg-blue-50 px-2 py-1 rounded text-xs font-bold">{t}</span>
                              ))}
                          </div>
                      )}
                  </div>

                  <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
                      <div className="text-xs font-semibold text-slate-500 flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full bg-green-500"></span>
                          {selectedPost.scheduledDate 
                            ? new Date(selectedPost.scheduledDate).toLocaleString('fr-FR', { weekday: 'long', hour: '2-digit', minute:'2-digit' })
                            : 'Brouillon'}
                      </div>
                      <div className="flex gap-3">
                         <button 
                            onClick={() => handleUnschedule(selectedPost)}
                            className="px-4 py-2 border border-slate-200 text-slate-600 text-sm font-bold rounded-lg hover:bg-white hover:text-red-600 hover:border-red-200 transition-colors bg-white shadow-sm"
                         >
                            Retirer
                         </button>
                         <button className="px-4 py-2 bg-slate-900 text-white text-sm font-bold rounded-lg hover:bg-slate-800 transition-colors shadow-lg">
                            Éditer
                         </button>
                      </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default Planning;
