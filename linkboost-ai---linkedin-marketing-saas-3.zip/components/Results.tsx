
import React, { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { Campaign, MarketingStrategy, SocialMediaPost, ChatMessage } from '../types';
import { sendChatMessage, refinePostWithAI, streamPostContent } from '../services/geminiService';

interface ResultsProps {
  campaigns: Campaign[];
  updateCampaign: (c: Campaign) => void;
}

const Results: React.FC<ResultsProps> = ({ campaigns, updateCampaign }) => {
  const { id } = useParams();
  const campaign = campaigns.find(c => c.id === id);
  
  // États pour le Chat Global (Widget)
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // États pour l'Éditeur Modal (Le cœur de la fonctionnalité)
  const [editingPostId, setEditingPostId] = useState<string | null>(null);
  const [editedPost, setEditedPost] = useState<SocialMediaPost | null>(null);
  const [editorAiInput, setEditorAiInput] = useState('');
  const [isAiRefining, setIsAiRefining] = useState(false);
  
  // Référence pour pouvoir arrêter le streaming
  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (campaign && chatMessages.length === 0) {
      setChatMessages([
        {
          role: 'model',
          text: `👋 Bienvenue dans votre espace de travail ${campaign.sector}.\n\nJe suis l'Agent Onari. Cliquez sur un post pour l'éditer ou posez-moi une question ici sur votre stratégie globale.`,
          timestamp: Date.now()
        }
      ]);
    }
  }, [campaign]);

  useEffect(() => {
    if (isChatOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, isChatOpen]);

  if (!campaign) return <div className="p-10 text-center font-bold text-slate-400">Chargement...</div>;
  const result = campaign.result as MarketingStrategy;

  // --- LOGIQUE ÉDITION POST ---

  const handleEditClick = (post: SocialMediaPost) => {
    setEditedPost({ ...post });
    setEditingPostId(post.id);
    setEditorAiInput('');
    setIsAiRefining(false);
  };

  const handleCreatePost = () => {
    const newPost: SocialMediaPost = {
      id: `new_${Date.now()}`,
      plateforme: 'LinkedIn',
      status: 'draft',
      type: 'Nouveau',
      hook: "Votre accroche ici...",
      body: "Écrivez votre contenu ou demandez à l'IA de le générer...",
      hashtags: [],
      conseil_visuel: ""
    };
    
    if (campaign.result) {
        const updatedPosts = [newPost, ...campaign.result.posts];
        updateCampaign({ ...campaign, result: { ...campaign.result, posts: updatedPosts } });
    }
    
    handleEditClick(newPost);
  };

  const handleSavePost = () => {
    if (campaign.result && editedPost) {
      const updatedPosts = campaign.result.posts.map(p => 
        p.id === editedPost.id ? editedPost : p
      );
      updateCampaign({ ...campaign, result: { ...campaign.result, posts: updatedPosts } });
    }
    setEditingPostId(null);
    setEditedPost(null);
  };

  const handleDeletePost = () => {
     if (campaign.result && editingPostId) {
        const updatedPosts = campaign.result.posts.filter(p => p.id !== editingPostId);
        updateCampaign({ ...campaign, result: { ...campaign.result, posts: updatedPosts } });
     }
     setEditingPostId(null);
     setEditedPost(null);
  };

  const stopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsAiRefining(false);
  };

  const handleAiRefine = async () => {
    if (!editorAiInput.trim() || !editedPost) return;
    setIsAiRefining(true);
    abortControllerRef.current = new AbortController();

    try {
      // Si l'instruction demande un changement structurel (JSON) ou juste du texte
      const isStructureChange = editorAiInput.toLowerCase().includes('hook') || editorAiInput.toLowerCase().includes('tag');
      
      if (isStructureChange) {
        const refined = await refinePostWithAI(editedPost, editorAiInput, campaign);
        setEditedPost(prev => prev ? {
          ...prev,
          hook: refined.hook || prev.hook,
          body: refined.body,
          hashtags: refined.hashtags && refined.hashtags.length > 0 ? refined.hashtags : prev.hashtags
        } : null);
      } else {
        // Mode Streaming pour le corps du texte (Temps réel)
        // On vide d'abord le corps si c'est une réécriture complète demandée
        if (editorAiInput.toLowerCase().includes('écris') || editorAiInput.toLowerCase().includes('génère')) {
            setEditedPost(prev => prev ? { ...prev, body: '' } : null);
        }

        await streamPostContent(editedPost, editorAiInput, campaign, (chunk) => {
          // Si l'utilisateur a arrêté, on ne fait rien
          if (!isAiRefining && !abortControllerRef.current) return;

          setEditedPost(prev => {
             if (!prev) return null;
             return { ...prev, body: prev.body + chunk };
          });
        });
      }
      setEditorAiInput('');
    } catch (e) {
      console.error(e);
      // Ignorer l'erreur si c'est un arrêt volontaire
    } finally {
      setIsAiRefining(false);
      abortControllerRef.current = null;
    }
  };

  // --- LOGIQUE CHAT GLOBAL ---

  const handleGlobalSend = async () => {
    if (!chatInput.trim() || isChatLoading) return;
    const userMsg: ChatMessage = { role: 'user', text: chatInput, timestamp: Date.now() };
    setChatMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setIsChatLoading(true);
    try {
      const resp = await sendChatMessage(userMsg.text, [...chatMessages, userMsg], campaign);
      setChatMessages(prev => [...prev, { role: 'model', text: resp, timestamp: Date.now() }]);
    } catch (e) {
      setChatMessages(prev => [...prev, { role: 'model', text: "Erreur de connexion.", timestamp: Date.now() }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  return (
    <div className="h-[calc(100vh-64px)] overflow-hidden relative bg-slate-50">
      
      {/* ZONE PRINCIPALE (Posts List) */}
      <div className="h-full overflow-y-auto p-8 custom-scrollbar">
        <div className="max-w-5xl mx-auto pb-32">
          <header className="mb-10 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
             <div>
                <h1 className="text-4xl font-black text-slate-900 mb-2">Studio <span className="text-blue-600">Onari.</span></h1>
                <p className="text-slate-500 font-medium">Campagne: {campaign.linkedinUrl}</p>
             </div>
             <button 
                onClick={handleCreatePost}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-blue-500/30 transition-all transform hover:scale-105 flex items-center gap-2"
             >
                <span className="text-xl">+</span> Créer un Post
             </button>
          </header>

          <div className="grid grid-cols-1 gap-6">
            {campaign.result?.posts.map((post, idx) => (
              <div 
                key={post.id} 
                onClick={() => handleEditClick(post)}
                className="group bg-white border-2 border-slate-100 rounded-[2.5rem] p-8 cursor-pointer hover:border-blue-600 hover:shadow-2xl hover:shadow-blue-500/10 transition-all duration-300 relative"
              >
                <div className="absolute top-8 right-8 opacity-0 group-hover:opacity-100 transition-opacity bg-blue-100 text-blue-700 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest flex items-center gap-2 shadow-sm">
                   <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/></svg>
                   Éditer
                </div>
                <div className="flex items-center gap-4 mb-6">
                   <span className="w-12 h-12 bg-slate-900 text-white rounded-2xl flex items-center justify-center font-black shadow-lg shadow-slate-900/20">{idx + 1}</span>
                   <span className="text-xs font-black text-slate-400 uppercase tracking-widest border border-slate-200 px-3 py-1 rounded-full">{post.type || 'Standard'}</span>
                </div>
                <h3 className="text-2xl font-black text-slate-900 mb-4 pr-16 leading-tight group-hover:text-blue-600 transition-colors">"{post.hook || 'Sans titre'}"</h3>
                <p className="text-slate-600 font-medium line-clamp-3 leading-relaxed text-lg">{post.body}</p>
                <div className="mt-6 flex flex-wrap gap-2">
                   {post.hashtags.slice(0, 3).map(t => (
                      <span key={t} className="text-xs font-bold text-blue-400 bg-blue-50 px-2 py-1 rounded-md">{t}</span>
                   ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* WIDGET CHAT FLOTTANT (Bulle) */}
      <div className="fixed bottom-8 right-8 z-40 flex flex-col items-end">
         
         {/* FENÊTRE DE CHAT (Visible uniquement si ouvert) */}
         {isChatOpen && (
            <div className="mb-4 w-[380px] h-[600px] max-h-[70vh] bg-white rounded-[2rem] shadow-2xl shadow-blue-900/20 border border-slate-100 flex flex-col overflow-hidden animate-in slide-in-from-bottom-10 fade-in duration-300 origin-bottom-right">
               {/* Header Chat */}
               <div className="bg-slate-900 p-6 flex items-center justify-between text-white rounded-t-[2rem]">
                  <div className="flex items-center gap-3">
                     <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center relative">
                        🤖
                        <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-slate-900 rounded-full"></span>
                     </div>
                     <div>
                        <h3 className="font-bold text-lg leading-none">Agent Onari</h3>
                        <span className="text-[10px] text-slate-400 font-medium uppercase tracking-widest">En ligne</span>
                     </div>
                  </div>
                  <button onClick={() => setIsChatOpen(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                     <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
                  </button>
               </div>
               
               <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50 custom-scrollbar">
                  {chatMessages.map((msg, i) => (
                     <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[85%] p-4 rounded-2xl text-sm font-medium leading-relaxed shadow-sm ${
                           msg.role === 'user' ? 'bg-blue-600 text-white rounded-tr-sm' : 'bg-white border border-slate-200 text-slate-700 rounded-tl-sm'
                        }`}>
                           {msg.text}
                        </div>
                     </div>
                  ))}
                  {isChatLoading && (
                     <div className="flex justify-start">
                        <div className="bg-white border border-slate-200 px-4 py-3 rounded-2xl rounded-tl-sm shadow-sm flex gap-1">
                           <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></span>
                           <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-150"></span>
                           <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-300"></span>
                        </div>
                     </div>
                  )}
                  <div ref={chatEndRef} />
               </div>

               <div className="p-4 bg-white border-t border-slate-100">
                  <div className="relative">
                     <input 
                        value={chatInput}
                        onChange={e => setChatInput(e.target.value)}
                        onKeyPress={e => e.key === 'Enter' && handleGlobalSend()}
                        placeholder="Une question sur la stratégie ?"
                        className="w-full bg-slate-100 border-0 rounded-xl px-4 py-4 pr-12 text-sm font-medium focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-slate-400"
                        autoFocus
                     />
                     <button 
                        onClick={handleGlobalSend} 
                        disabled={!chatInput.trim() || isChatLoading}
                        className="absolute right-2 top-2 bottom-2 aspect-square bg-blue-600 text-white rounded-lg flex items-center justify-center hover:bg-blue-700 disabled:opacity-50 transition-colors shadow-lg shadow-blue-500/30"
                     >
                        <svg className="w-5 h-5 transform rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
                     </button>
                  </div>
               </div>
            </div>
         )}

         <button 
            onClick={() => setIsChatOpen(!isChatOpen)}
            className={`w-16 h-16 rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 hover:scale-110 ${
               isChatOpen ? 'bg-slate-900 rotate-90' : 'bg-blue-600 hover:bg-blue-700'
            }`}
         >
            {isChatOpen ? (
               <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
            ) : (
               <div className="relative">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
                  <span className="absolute -top-1 -right-1 flex h-3 w-3">
                     <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                     <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500 border-2 border-blue-600"></span>
                  </span>
               </div>
            )}
         </button>
      </div>

      {/* MODAL ÉDITION AVANCÉE */}
      {editingPostId && editedPost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
           <div className="bg-white w-full max-w-6xl h-[90vh] rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col md:flex-row">
              
              {/* COLONNE GAUCHE : ÉDITEUR MANUEL */}
              <div className="flex-1 flex flex-col border-r border-slate-100 bg-white">
                 <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                    <h3 className="font-black text-xl text-slate-900 flex items-center gap-2">
                       ✏️ Éditeur Manuel
                    </h3>
                    <div className="flex gap-2">
                       <button onClick={handleDeletePost} className="p-2 text-red-400 hover:bg-red-50 rounded-xl transition-colors" title="Supprimer">
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                       </button>
                    </div>
                 </div>
                 <div className="flex-1 overflow-y-auto p-8 space-y-6 custom-scrollbar">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Accroche (Hook)</label>
                       <textarea 
                          value={editedPost.hook || ''}
                          onChange={e => setEditedPost({...editedPost, hook: e.target.value})}
                          className="w-full text-2xl font-black text-slate-900 bg-transparent border-0 border-b-2 border-slate-100 focus:border-blue-600 focus:ring-0 p-0 pb-4 resize-none placeholder:text-slate-200"
                          rows={2}
                          placeholder="Votre accroche percutante ici..."
                       />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Corps du post</label>
                       <textarea 
                          value={editedPost.body}
                          onChange={e => setEditedPost({...editedPost, body: e.target.value})}
                          className="w-full text-lg font-medium text-slate-700 bg-transparent border-0 focus:ring-0 p-0 h-[400px] resize-none leading-relaxed placeholder:text-slate-300"
                          placeholder="Écrivez votre contenu ou demandez à l'IA..."
                       />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Hashtags</label>
                       <input 
                          value={editedPost.hashtags.join(' ')}
                          onChange={e => setEditedPost({...editedPost, hashtags: e.target.value.split(' ')})}
                          className="w-full text-blue-600 font-bold bg-blue-50 rounded-xl px-4 py-3 border-0 focus:ring-2 focus:ring-blue-200"
                       />
                    </div>
                 </div>
                 <div className="p-6 border-t border-slate-100 flex justify-between items-center bg-slate-50">
                    <span className="text-xs font-bold text-slate-400">{editedPost.body.length} caractères</span>
                    <div className="flex gap-4">
                       <button onClick={() => { setEditingPostId(null); setEditedPost(null); }} className="text-slate-500 font-bold hover:text-slate-900">Annuler</button>
                       <button onClick={handleSavePost} className="bg-slate-900 text-white px-8 py-3 rounded-xl font-black uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg">Sauvegarder</button>
                    </div>
                 </div>
              </div>

              {/* COLONNE DROITE : IA CO-PILOTE */}
              <div className="w-full md:w-[400px] bg-slate-900 text-white flex flex-col">
                 <div className="p-6 border-b border-white/10 flex justify-between items-center">
                    <div>
                        <h3 className="font-black text-xl flex items-center gap-2 text-white">
                        🤖 Co-Pilote IA
                        </h3>
                        <p className="text-xs text-slate-400 mt-1">Édition ciblée pour ce post.</p>
                    </div>
                 </div>
                 
                 <div className="flex-1 p-6 flex flex-col justify-center items-center text-center space-y-6">
                    <div className="w-20 h-20 bg-blue-600/20 rounded-full flex items-center justify-center mb-4 relative">
                       <span className="text-4xl">✨</span>
                       {isAiRefining && (
                           <div className="absolute inset-0 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                       )}
                    </div>
                    <div>
                       <h4 className="font-bold text-lg mb-2">Instructions d'édition</h4>
                       <div className="flex flex-wrap justify-center gap-2">
                          {["Rends-le plus court", "Ajoute une touche d'humour", "Change le ton (Autoritaire)", "Génère un post sur l'IA"].map(sugg => (
                             <button 
                                key={sugg} 
                                onClick={() => setEditorAiInput(sugg)}
                                className="text-xs bg-white/5 hover:bg-white/10 border border-white/10 px-3 py-1.5 rounded-full transition-colors"
                             >
                                {sugg}
                             </button>
                          ))}
                       </div>
                    </div>
                 </div>

                 <div className="p-6 bg-slate-800">
                    <div className="relative">
                       <textarea 
                          value={editorAiInput}
                          onChange={e => setEditorAiInput(e.target.value)}
                          onKeyPress={e => e.key === 'Enter' && !e.shiftKey && handleAiRefine()}
                          placeholder="Ex: 'Écris un post sur...' ou 'Raccourcis le texte'..."
                          className="w-full bg-slate-900 border-2 border-slate-700 rounded-2xl p-4 pr-12 text-sm text-white focus:border-blue-500 outline-none resize-none h-24"
                       />
                       
                       {isAiRefining ? (
                          <button 
                            onClick={stopGeneration}
                            className="absolute right-3 bottom-3 p-2 bg-red-500 rounded-lg hover:bg-red-600 transition-all text-white flex items-center gap-1 shadow-lg animate-in zoom-in"
                          >
                             <div className="w-2 h-2 bg-white rounded-sm"></div>
                             <span className="text-[10px] font-black uppercase">Stop</span>
                          </button>
                       ) : (
                          <button 
                            onClick={handleAiRefine}
                            disabled={!editorAiInput.trim()}
                            className="absolute right-3 bottom-3 p-2 bg-blue-600 rounded-lg hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                          >
                             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                          </button>
                       )}
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Results;
