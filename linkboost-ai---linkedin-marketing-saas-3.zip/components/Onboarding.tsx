
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Campaign, CampaignTone, User } from '../types';
import { campaignService } from '../services/campaignService';

interface OnboardingProps {
  onComplete: (c: Campaign) => void;
  user: User;
}

// Fix: Made children optional to prevent TypeScript error when using nested JSX children
// and updated onNext to accept both void and Promise<void> for flexible usage.
const StepContent = ({ step, totalSteps, title, subtitle, children, onNext, onPrev, isLast }: { 
  step: number, 
  totalSteps: number, 
  title: string, 
  subtitle: string, 
  children?: React.ReactNode,
  onNext: () => void | Promise<void>,
  onPrev: () => void,
  isLast: boolean
}) => (
  <div className="max-w-4xl mx-auto min-h-screen flex flex-col justify-center px-6 py-20 animate-in fade-in slide-in-from-bottom-12 duration-700">
    <div className="mb-12">
      <span className="inline-block px-4 py-1 rounded-full bg-blue-100 text-blue-700 text-xs font-black uppercase tracking-widest mb-6">Configuration Initiale : {step}/{totalSteps}</span>
      <h1 className="text-5xl md:text-7xl font-black text-slate-900 leading-[1.1] tracking-tighter mb-6">{title}</h1>
      <p className="text-xl md:text-2xl text-slate-500 font-medium">{subtitle}</p>
    </div>
    <div className="mb-16">
      {children}
    </div>
    <div className="flex items-center gap-6">
      <button 
        onClick={onNext}
        className="px-12 py-5 bg-blue-600 text-white font-black rounded-2xl hover:bg-blue-700 transition-all shadow-2xl shadow-blue-500/40 text-xl flex items-center gap-4 group"
      >
        {isLast ? "Lancer mon Analyse Onari" : "Suivant"}
        <svg className="w-6 h-6 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 7l5 5-5 5M6 7l5 5-5 5"/></svg>
      </button>
      {step > 1 && (
        <button onClick={onPrev} className="text-slate-400 font-bold hover:text-slate-600 transition-colors">Retour</button>
      )}
    </div>
  </div>
);

const Onboarding: React.FC<OnboardingProps> = ({ onComplete, user }) => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);

  const [formData, setFormData] = useState({
    linkedinUrl: '',
    goal: 'Visibilité massive',
    sector: '',
    tone: CampaignTone.PROFESSIONAL,
    targetAudience: '',
    currentChallenge: '',
  });

  const totalSteps = 6;

  const analysisSteps = [
    "Initialisation du Deep-Scan...",
    "Exploration de votre profil...",
    "Détection des points de friction...",
    "Architecture du plan Onari...",
    "Rédaction des posts viraux...",
    "Finalisation du rapport..."
  ];

  const nextStep = () => {
    if (step < totalSteps) setStep(step + 1);
    else handleFinish();
  };

  const handleFinish = async () => {
    setLoading(true);
    const interval = setInterval(() => {
      setLoadingStep(prev => (prev < analysisSteps.length - 1 ? prev + 1 : prev));
    }, 2500);

    const newId = 'onb-' + Math.random().toString(36).substring(7);
    try {
      const strategy = await campaignService.processCampaign(formData);
      
      const campaign: Campaign = {
        ...formData,
        id: newId,
        createdAt: new Date().toISOString(),
        status: 'completed',
        result: strategy
      };

      onComplete(campaign);
      clearInterval(interval);
      navigate(`/campaign/results/${newId}`);
    } catch (error) {
      console.error("Erreur Onboarding:", error);
      clearInterval(interval);
      setLoading(false);
      alert("L'IA est surchargée ou l'URL est invalide. Veuillez réessayer dans quelques instants.");
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-white z-[100] flex flex-col items-center justify-center p-8 text-center animate-in fade-in duration-500">
        <div className="relative w-48 h-48 mb-12">
          <div className="absolute inset-0 border-8 border-slate-100 rounded-full"></div>
          <div className="absolute inset-0 border-8 border-blue-600 rounded-full border-t-transparent animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
             <span className="text-4xl animate-bounce">🧠</span>
          </div>
        </div>
        <h2 className="text-4xl font-black text-slate-900 mb-4 tracking-tight">{analysisSteps[loadingStep]}</h2>
        <p className="text-slate-500 max-w-sm mx-auto font-medium">L'IA Onari construit votre futur sur LinkedIn.</p>
        <button 
          onClick={() => { setLoading(false); }}
          className="mt-12 text-xs font-black text-slate-300 uppercase tracking-widest hover:text-slate-900 transition-colors"
        >
          Annuler l'attente
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white w-full">
      <div className="fixed top-0 left-0 right-0 h-2 bg-slate-50 z-50">
        <div className="h-full bg-blue-600 transition-all duration-700" style={{ width: `${(step/totalSteps)*100}%` }}></div>
      </div>

      {step === 1 && (
        <StepContent 
          step={step} totalSteps={totalSteps} onNext={nextStep} onPrev={() => {}} isLast={false}
          title="Votre identité." 
          subtitle="Collez l'URL de votre profil LinkedIn pour démarrer l'audit Onari."
        >
          <input 
            autoFocus type="url" placeholder="https://linkedin.com/in/votre-nom"
            className="w-full bg-transparent border-b-4 border-slate-100 py-6 text-3xl md:text-5xl font-black outline-none focus:border-blue-600 transition-colors placeholder:text-slate-200"
            value={formData.linkedinUrl}
            onChange={e => setFormData({...formData, linkedinUrl: e.target.value})}
            onKeyPress={e => e.key === 'Enter' && nextStep()}
          />
        </StepContent>
      )}

      {step === 2 && (
        <StepContent 
          step={step} totalSteps={totalSteps} onNext={nextStep} onPrev={() => setStep(step - 1)} isLast={false}
          title="Votre expertise." 
          subtitle="Dans quel domaine voulez-vous devenir une référence ?"
        >
          <input 
            autoFocus type="text" placeholder="Ex: Finance, Immobilier, Tech..."
            className="w-full bg-transparent border-b-4 border-slate-100 py-6 text-3xl md:text-5xl font-black outline-none focus:border-blue-600 transition-colors placeholder:text-slate-200"
            value={formData.sector}
            onChange={e => setFormData({...formData, sector: e.target.value})}
            onKeyPress={e => e.key === 'Enter' && nextStep()}
          />
        </StepContent>
      )}

      {step === 3 && (
        <StepContent 
          step={step} totalSteps={totalSteps} onNext={nextStep} onPrev={() => setStep(step - 1)} isLast={false}
          title="Votre cible." 
          subtitle="Qui sont les décideurs que vous voulez convaincre ?"
        >
          <input 
            autoFocus type="text" placeholder="Ex: Les DRH de grands comptes..."
            className="w-full bg-transparent border-b-4 border-slate-100 py-6 text-2xl md:text-4xl font-black outline-none focus:border-blue-600 transition-colors placeholder:text-slate-200"
            value={formData.targetAudience}
            onChange={e => setFormData({...formData, targetAudience: e.target.value})}
            onKeyPress={e => e.key === 'Enter' && nextStep()}
          />
        </StepContent>
      )}

      {step === 4 && (
        <StepContent 
          step={step} totalSteps={totalSteps} onNext={nextStep} onPrev={() => setStep(step - 1)} isLast={false}
          title="Votre objectif." 
          subtitle="Quelle est votre priorité numéro 1 aujourd'hui ?"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {['Visibilité massive', 'Génération de rendez-vous', 'Expertise & Crédibilité', 'Recrutement'].map(g => (
              <button 
                key={g}
                onClick={() => { setFormData({...formData, goal: g}); setStep(5); }}
                className={`p-8 rounded-[2rem] border-4 text-left transition-all ${formData.goal === g ? 'border-blue-600 bg-blue-50 text-blue-900 shadow-xl' : 'border-slate-50 hover:border-slate-100 text-slate-500'}`}
              >
                <span className="text-2xl font-black">{g}</span>
              </button>
            ))}
          </div>
        </StepContent>
      )}

      {step === 5 && (
        <StepContent 
          step={step} totalSteps={totalSteps} onNext={nextStep} onPrev={() => setStep(step - 1)} isLast={false}
          title="Votre voix." 
          subtitle="Quel ton Onari doit-il adopter pour vos contenus ?"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.values(CampaignTone).map(t => (
              <button 
                key={t}
                onClick={() => { setFormData({...formData, tone: t}); setStep(6); }}
                className={`p-6 rounded-3xl border-4 text-center transition-all ${formData.tone === t ? 'border-blue-600 bg-blue-50 text-blue-900 shadow-xl' : 'border-slate-50 hover:border-slate-100 text-slate-500'}`}
              >
                <span className="text-lg font-black">{t}</span>
              </button>
            ))}
          </div>
        </StepContent>
      )}

      {step === 6 && (
        <StepContent 
          step={step} totalSteps={totalSteps} onNext={handleFinish} onPrev={() => setStep(step - 1)} isLast={true}
          title="Votre obstacle." 
          subtitle="Qu'est-ce qui vous freine aujourd'hui sur LinkedIn ?"
        >
          <textarea 
            autoFocus rows={2} placeholder="Ex: Pas le temps d'écrire, peur d'être jugé..."
            className="w-full bg-transparent border-b-4 border-slate-100 py-6 text-2xl md:text-4xl font-black outline-none focus:border-blue-600 transition-colors resize-none placeholder:text-slate-200"
            value={formData.currentChallenge}
            onChange={e => setFormData({...formData, currentChallenge: e.target.value})}
          />
        </StepContent>
      )}
    </div>
  );
};

export default Onboarding;
