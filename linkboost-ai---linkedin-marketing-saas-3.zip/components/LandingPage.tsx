
import React from 'react';
import { Link } from 'react-router-dom';
import { User } from '../types';

interface LandingPageProps {
  login: (u: User) => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ login }) => {
  const handleStart = () => {
    // Fix: Added missing linkedInConnected property to satisfy User type
    login({
      id: '1',
      email: 'jean.dupont@example.com',
      name: 'Jean Dupont',
      credits: 10,
      role: 'admin',
      linkedInConnected: false
    });
  };

  return (
    <div className="relative overflow-hidden">
      {/* Hero Section */}
      <section className="pt-20 pb-32 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-600 text-sm font-semibold mb-8 border border-blue-100">
            <span className="flex h-2 w-2 rounded-full bg-blue-600 animate-pulse"></span>
            Nouveau : Analyse de profil par IA v2.5
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold text-slate-900 tracking-tight mb-8 leading-[1.1]">
            Boostez votre visibilité <br />
            <span className="text-blue-600">LinkedIn avec l'IA.</span>
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-12 leading-relaxed">
            Analysez votre profil, créez une stratégie marketing sur mesure et générez 5 posts viraux en moins de 2 minutes.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              onClick={handleStart}
              className="w-full sm:w-auto px-8 py-4 bg-blue-600 text-white font-bold rounded-xl text-lg hover:bg-blue-700 hover:scale-105 transition-all shadow-xl shadow-blue-500/25"
            >
              Démarrer l'essai gratuit
            </button>
            <button className="w-full sm:w-auto px-8 py-4 bg-white text-slate-700 border border-slate-200 font-bold rounded-xl text-lg hover:bg-slate-50 transition-all">
              Voir la démo
            </button>
          </div>
          
          <div className="mt-20 relative">
            <div className="absolute inset-0 bg-gradient-to-t from-slate-50 to-transparent z-10 h-32 bottom-0"></div>
            <img 
              src="https://picsum.photos/1200/600?grayscale" 
              alt="Dashboard Preview" 
              className="rounded-3xl border shadow-2xl mx-auto object-cover h-[400px] w-full max-w-5xl"
            />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-white px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Tout ce dont vous avez besoin pour percer</h2>
            <p className="text-slate-600">L'IA de LinkBoost automatise 90% de votre travail sur LinkedIn.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-12">
            {[
              {
                title: "Audit de Profil IA",
                desc: "Analyse complète de votre profil LinkedIn pour optimiser votre tunnel de conversion.",
                icon: (
                  <svg className="w-10 h-10 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                )
              },
              {
                title: "Génération de Posts",
                desc: "5 posts prêts à publier chaque semaine, adaptés à votre ton et vos objectifs business.",
                icon: (
                  <svg className="w-10 h-10 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                )
              },
              {
                title: "Stratégie de Croissance",
                desc: "Un plan d'action détaillé pour atteindre vos objectifs de prospection ou de visibilité.",
                icon: (
                  <svg className="w-10 h-10 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
                )
              }
            ].map((f, i) => (
              <div key={i} className="p-8 rounded-2xl border border-slate-100 hover:border-blue-200 hover:shadow-lg transition-all">
                <div className="mb-6">{f.icon}</div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{f.title}</h3>
                <p className="text-slate-600 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-24 px-6 bg-slate-50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Des tarifs simples et transparents</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
              <h3 className="text-lg font-bold text-slate-900 mb-2">Solo</h3>
              <p className="text-4xl font-black text-slate-900 mb-6">29€<span className="text-lg font-normal text-slate-500">/mois</span></p>
              <ul className="space-y-4 mb-8 flex-1">
                {["5 Analyses par mois", "25 Posts générés", "Export Google Sheets", "Support email"].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-slate-600">
                    <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"/></svg>
                    {item}
                  </li>
                ))}
              </ul>
              <button 
                onClick={handleStart}
                className="w-full py-3 bg-slate-100 text-slate-900 font-bold rounded-xl hover:bg-slate-200 transition-colors"
              >
                Choisir Solo
              </button>
            </div>
            <div className="bg-blue-600 p-8 rounded-2xl border border-blue-700 shadow-xl shadow-blue-500/20 text-white flex flex-col relative scale-105">
              <div className="absolute -top-4 right-8 bg-amber-400 text-slate-900 px-3 py-1 rounded-full text-xs font-black uppercase tracking-widest">Populaire</div>
              <h3 className="text-lg font-bold mb-2">Pro</h3>
              <p className="text-4xl font-black mb-6">59€<span className="text-lg font-normal opacity-70">/mois</span></p>
              <ul className="space-y-4 mb-8 flex-1">
                {["Analyses illimitées", "Posts illimités", "Multi-comptes", "Stratégie PDF personnalisée", "Support prioritaire"].map((item, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <svg className="w-5 h-5 text-blue-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"/></svg>
                    {item}
                  </li>
                ))}
              </ul>
              <button 
                onClick={handleStart}
                className="w-full py-3 bg-white text-blue-600 font-bold rounded-xl hover:bg-blue-50 transition-colors"
              >
                Choisir Pro
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer avec lien Privacy */}
      <footer className="bg-white py-12 px-6 border-t border-slate-100">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2">
                <span className="text-xl font-bold text-slate-900">LinkBoost AI</span>
            </div>
            <div className="flex items-center gap-8 text-sm text-slate-500 font-medium">
                <Link to="/privacy" className="hover:text-blue-600 transition-colors">Politique de Confidentialité</Link>
                <a href="#" className="hover:text-blue-600 transition-colors">CGU</a>
                <a href="#" className="hover:text-blue-600 transition-colors">Contact</a>
            </div>
            <div className="text-sm text-slate-400">
                © {new Date().getFullYear()} Onari. Tous droits réservés.
            </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
