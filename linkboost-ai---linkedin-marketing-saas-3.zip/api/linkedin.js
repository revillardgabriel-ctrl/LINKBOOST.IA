
export default async function handler(req, res) {
  // Cette fonction tourne sur le serveur Vercel, pas dans le navigateur.
  // Vos secrets sont en sécurité ici.

  // 1. Récupération des clés depuis les variables d'environnement Vercel
  const CLIENT_ID = process.env.VITE_LINKEDIN_CLIENT_ID;
  const CLIENT_SECRET = process.env.LINKEDIN_CLIENT_SECRET;
  const REDIRECT_URI = req.headers.origin + '/auth/callback'; // Détection automatique de l'URL (localhost ou vercel.app)

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { code } = req.body;

  if (!code) {
    return res.status(400).json({ error: 'Code manquant' });
  }

  try {
    // 2. Échange du code contre un Access Token
    const tokenResponse = await fetch('https://www.linkedin.com/oauth/v2/accessToken', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code: code,
        redirect_uri: REDIRECT_URI,
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
      }),
    });

    const tokenData = await tokenResponse.json();

    if (tokenData.error) {
      throw new Error(tokenData.error_description || 'Erreur LinkedIn Token');
    }

    const accessToken = tokenData.access_token;

    // 3. Récupération du profil utilisateur avec le token
    const profileResponse = await fetch('https://api.linkedin.com/v2/me', {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    const profileData = await profileResponse.json();

    // 4. (Optionnel) Récupération de l'email - nécessite scope r_emailaddress
    // Note: L'API email est séparée, on simplifie ici en renvoyant le profil de base.

    // 5. Récupération de la photo (Profile Picture)
    // L'API LinkedIn pour les images est complexe, ceci est une simplification
    // Souvent l'image est dans profileData.profilePicture...

    return res.status(200).json({
      success: true,
      user: {
        id: profileData.id,
        firstName: profileData.localizedFirstName,
        lastName: profileData.localizedLastName,
        // On simule l'avatar car l'API V2 Image est très verbeuse à parser
        avatar: `https://ui-avatars.com/api/?name=${profileData.localizedFirstName}+${profileData.localizedLastName}&background=0D8ABC&color=fff`
      }
    });

  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: error.message });
  }
}
